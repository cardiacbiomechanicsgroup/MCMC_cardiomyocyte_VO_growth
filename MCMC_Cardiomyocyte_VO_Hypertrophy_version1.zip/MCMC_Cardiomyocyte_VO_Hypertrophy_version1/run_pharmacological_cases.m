%% Run pharmacological alternatives
% Main program and subroutines by Johane Bracamonte, Ph.D.
% University of Alabama at Birmingham, USA. 

% This routine runs Monte Carlo Simulations of pharmacological alternatives
% in the context of VO. The probability distribution of model input parameters
% are obtained from a Markov-Chain Monte Carlo analysis as described in
% Bracamonte et al. (2024) PLOS Computational Biology.

% Adding library folders
addpath(genpath('Functions_MCMC'));
addpath(genpath('Functions_Pharma'));
addpath(genpath('Functions_Stretch'));

tG=5700;

%Running relevant pharmacological interventions.
VO=NetInfusionMCv7('VO',{'ET1R'},tG);
AT1R=NetInfusionMCv7('VO',{'AT1R'},tG);
ET1R=NetInfusionMCv7('VO',{'ET1R'},tG);
BAR=NetInfusionMCv7('VO',{'BAR'},tG);
AT1R_BAR=NetInfusionMCv7('VO',{'BAR','AT1R'},4008);
ET1R_BAR=NetInfusionMCv7('VO',{'BAR','ET1R'},4008);
ET1R_AT1R=NetInfusionMCv7('VO',{'AT1R','ET1R'},4008);
CaN=NetInfusionMCv7('VO',{'CaN'},4008);
CREB=NetInfusionMCv7('VO',{'CREB'},4008);
TAK1=NetInfusionMCv7('VO',{'TAK1'},4008);
PKD=NetInfusionMCv7('VO',{'PKD'},4008);
CaMK=NetInfusionMCv7('VO',{'CaMK'},4008);