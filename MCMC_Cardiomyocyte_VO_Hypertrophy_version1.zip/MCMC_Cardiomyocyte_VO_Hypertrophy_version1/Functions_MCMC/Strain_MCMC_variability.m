function NetStrain=Strain_MCMC_variability
%Read data
addpath(genpath('Functions_MCMC'));
addpath(genpath('Functions_Pharma'));
addpath(genpath('Functions_Stretch'));
Experimental_Data;
%Calculate Mass-Volume Covariance
Netfit=f_EDVMass_corr2(Netfit) %Altered COVA
%Netfit=f_EDVMass_corr(Netfit)
Netfit.strains=[];

%Initialize arrays and sets
ll_set=[];
fpar_set=[];
curve_set=[];
input_set=[];
Netfit.mvrat_now=[]; %m/v_0 m/v_final dm/dv_final
Netfit.mvrat_set=[]; %m/v_0 m/v_final dm/dv_final
%Gibbs method
iterations=10000;
Netfit.Gibbs.N=5;
Netfit.Gibbs.iGibbs=1;
Netfit.Gibbs.jGibbs=1;
Netfit.Gibbs.Nj=10;

%Model parameters
Netfit.tG=5700;
Netfit.tsteps=2;

%First step
pars0=[0.2 500];
V0=19.0;
EDV0=Exp.Base.EDV(1);
EDh=Exp.Base.h(1);
EDVA=0.8850;
EDVB=1175;
EDVC=1.1653;

EDr = (3*EDV0/(4*pi))^(1/3);
LVwall0=(4*pi/3)*((EDr+EDh)^3-EDr^3);


r0 = (3*V0/(4*pi))^(1/3);
h0=(r0^3+3*LVwall0/(4*pi))^(1/3) - r0;
lbf0=EDr/r0;
strf0=0.5*(lbf0^2-1);

Fpars=random_MassPars(pars0,Netfit);
Netfit.Fpars=Fpars;

Netfit.V0=V0;
Netfit.r0=r0;
Netfit.h0=h0;
Netfit.lbf0=lbf0;
Netfit.strf0=strf0;
Netfit.EDV0=EDV0;
Netfit.LVwall0=LVwall0;
Netfit.EDh0=EDh;
Netfit.EDr0=EDr;
Netfit.EDVA=EDVA;
Netfit.EDVB=EDVB;
Netfit.EDVC=EDVC;

ll=F_likelyhood5(Netfit.Exp.Mass, Netfit);
Netfit=get_strain_curve6(Netfit);
curve=Netfit.curve;

ll_set=[ll_set; ll];
fpar_set=[fpar_set; Fpars];
curve_set=[curve_set; curve];
input_set=[input_set; V0 r0 h0 lbf0 strf0 EDV0 LVwall0 EDh EDr EDVA EDVB EDVC];
Netfit.mvrat_set=[Netfit.mvrat_set; Netfit.mvrat_now];
Netfit.curve0=curve;

 
for i=1:iterations
    if Netfit.Gibbs.jGibbs>0
        if Netfit.Gibbs.jGibbs>Netfit.Gibbs.Nj;
            Netfit.Gibbs.jGibbs=1;
            arr=-1*ones(1,6);
            while(any(arr<0) || EDVC<1.0 || EDVB>2000)
                EDV0=random('Normal',Exp.Base.EDV(1),Exp.Base.EDV(2));
                %V0=random('Normal',19.10,8.52);
                V0=EDV0/(1.44^(3));
                EDh=random('Normal',Exp.Base.h(1),Exp.Base.h(2));
                EDVA=random('Normal',0.47,0.2045);
                EDVB=random('Uniform',100,1080);
                EDVC=random('Normal',1.15,0.11);
                arr=[V0 EDV0 EDh EDVA EDVB EDVC];
            end
        else
            Netfit.Gibbs.jGibbs=Netfit.Gibbs.jGibbs+1;
        end
    else
        arr=-1*ones(1,6);
        while(any(arr<0) || EDVC<1.0 || EDVB>2000)
            EDV0=random('Normal',Exp.Base.EDV(1),Exp.Base.EDV(2));
            %V0=random('Normal',19.10,8.52);
            V0=EDV0/(1.44^(3));
            EDh=random('Normal',Exp.Base.h(1),Exp.Base.h(2));
            EDVA=random('Normal',0.47,0.2045);
            EDVB=random('Uniform',100,1080);
            EDVC=random('Normal',1.15,0.11);
            arr=[V0 EDV0 EDh EDVA EDVB EDVC];
        end        
    end
    EDr = (3*EDV0/(4*pi))^(1/3);
    LVwall0=(4*pi/3)*((EDr+EDh)^3-EDr^3);


    r0 =(3*V0/(4*pi))^(1/3);
    h0=(r0^3+3*LVwall0/(4*pi)*(1))^(1/3) - r0;
    lbf0=EDr/r0;
    strf0=0.5*(lbf0^2-1);

    Fpars=random_MassPars(pars0,Netfit);
    Netfit.Fpars=Fpars;

    Netfit.V0=V0;
    Netfit.r0=r0;
    Netfit.h0=h0;
    Netfit.lbf0=lbf0;
    Netfit.strf0=strf0;
    Netfit.EDV0=EDV0;
    Netfit.LVwall0=LVwall0;
    Netfit.EDh0=EDh;
    Netfit.EDr0=EDr;
    Netfit.EDVA=EDVA;
    Netfit.EDVB=EDVB;
    Netfit.EDVC=EDVC;
    %Get results
    ll=F_likelyhood5(Netfit.Exp.Mass, Netfit);
    Netfit=get_strain_curve6(Netfit);
    %Netfit.curve=curve;
    curve=Netfit.curve;
    %Metropolis Hastings
    randt=random('Uniform',0,1);
    %test=exp(ll-ll_set(end));
    test=ll_set(end)/ll;
    if test>randt
        ll_set=[ll_set; ll];
        fpar_set=[fpar_set; Fpars];
        curve_set=[curve_set; curve];
        input_set=[input_set; V0 r0 h0 lbf0 strf0 EDV0 LVwall0 EDh EDr EDVA EDVB EDVC];
        Netfit.curve0=curve;
        pars0=Fpars;
        Netfit.strains=[Netfit.strains curve(:,2)];
        Netfit.mvrat_set=[Netfit.mvrat_set; Netfit.mvrat_now];
    else
        ll_set=[ll_set; ll_set(end)];
        fpar_set=[fpar_set; fpar_set(end,:)];
        input_set=[input_set; input_set(end,:)];
        curve_set=[curve_set; Netfit.curve0];
        Netfit.strains=[Netfit.strains Netfit.curve0(:,2)];
        Netfit.mvrat_set=[Netfit.mvrat_set; Netfit.mvrat_set(end,:)];
    end
    if Netfit.Gibbs.iGibbs>0
        if Netfit.Gibbs.iGibbs>2*Netfit.Gibbs.N;
            Netfit.Gibbs.iGibbs=1;
        else
            Netfit.Gibbs.iGibbs=Netfit.Gibbs.iGibbs+1;
        end
    end
end

Netfit.ll_set=ll_set;
Netfit.fpar_set=fpar_set;
Netfit.curves=curve_set;
Netfit.input_set=input_set;

figure
histogram(fpar_set(:,1));
xlabel('Fg Parameter A');
figure
histogram(fpar_set(:,2));
xlabel('Fg Parameter B');
figure
histogram(ll_set);
xlabel('Likelyhood');

% Writting
writematrix(real(ll_set),'Likelyhood_set9.txt','Delimiter',',');
writematrix(real(fpar_set),'Fg_parameter_set9.txt','Delimiter',',');
%writematrix(real(input_set),'Input_set6.txt','Delimiter',',');
writematrix(real(curve_set),'Curve_set9r.txt','Delimiter',',');
writematrix(curve_set,'Curve_set9.txt','Delimiter',',');
writematrix(Netfit.strains,'Strain_samples_fromM-VData.txt','Delimiter',',');
writematrix(Netfit.mvrat_set,'MassVolumeRatio.txt','Delimiter',',');

strain_stats=[];
strainn_stats=[];
EDV_stats=[];
EDVn_stats=[];
LVmass_stats=[];

idx0=find(curve_set(:,1)==0);
EDVi0=curve_set(idx0,7);

for i=0:Netfit.tsteps:Netfit.tG
    idxs=find(curve_set(:,1)==i);
    strains=curve_set(idxs,2);
    strainn=curve_set(idxs,3);
    EDVis=curve_set(idxs,7);
    EDVin=EDVis./EDVi0;
    LVms=curve_set(idxs,end);
    strQ=quantile(strains,[0.05 0.165 0.25 0.5 0.75 0.835 0.95]);
    strnQ=quantile(strainn,[0.05 0.165 0.25 0.5 0.75 0.835 0.95]);
    EDVQ=quantile(EDVis,[0.05 0.165 0.25 0.5 0.75 0.835 0.95]);
    EDVnQ=quantile(EDVin,[0.05 0.165 0.25 0.5 0.75 0.835 0.95]);
    LVmQ=quantile(LVms,[0.05 0.165 0.25 0.5 0.75 0.835 0.95]);
    strain_stats=[strain_stats; i strQ];
    strainn_stats=[strainn_stats; i strnQ];
    EDV_stats=[EDV_stats; i EDVQ];
    EDVn_stats=[EDVn_stats; i EDVnQ];
    LVmass_stats=[LVmass_stats; i LVmQ];
end


Netfit.Stats.strain=strain_stats;
Netfit.Stats.strain_normalized=strainn_stats;
Netfit.Stats.EDV=EDV_stats;
Netfit.Stats.EDV_normalized=EDVn_stats;
Netfit.Stats.LV_mass=LVmass_stats;

figure
plot(LVmass_stats(:,1),LVmass_stats(:,5),'Color','k')
hold on
plot(LVmass_stats(:,1),LVmass_stats(:,3),'Color','k','LineStyle','--')
plot(LVmass_stats(:,1),LVmass_stats(:,7),'Color','k','LineStyle','--')
plot(LVmass_stats(:,1),LVmass_stats(:,6),'Color',[0.7 0.7 0.7],'LineStyle','-.')
plot(LVmass_stats(:,1),LVmass_stats(:,4),'Color',[0.7 0.7 0.7],'LineStyle','-.')
plot(LVmass_stats(:,1),LVmass_stats(:,8),'Color','k','LineStyle','-.')
plot(LVmass_stats(:,1),LVmass_stats(:,2),'Color','k','LineStyle','-.')
Mass=Netfit.Exp.Mass;
errorbar(Mass.t,Mass.y,Mass.e,'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
xlabel('Time [hours]');
ylabel('LV mass fold change');

figure
plot(EDVn_stats(:,1),EDVn_stats(:,5),'Color','k')
hold on
plot(EDVn_stats(:,1),EDVn_stats(:,3),'Color','k','LineStyle','--')
plot(EDVn_stats(:,1),EDVn_stats(:,7),'Color','k','LineStyle','--')
plot(EDVn_stats(:,1),EDVn_stats(:,6),'Color',[0.7 0.7 0.7],'LineStyle','-.')
plot(EDVn_stats(:,1),EDVn_stats(:,4),'Color',[0.7 0.7 0.7],'LineStyle','-.')
plot(EDVn_stats(:,1),EDVn_stats(:,8),'Color','k','LineStyle','-.')
plot(EDVn_stats(:,1),EDVn_stats(:,2),'Color','k','LineStyle','-.')
Mass=Netfit.Exp.EDV;
errorbar(Mass.t,Mass.y,Mass.e,'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
xlabel('Time [hours]');
ylabel('EDV fold change');


figure
plot(strain_stats(:,1),strain_stats(:,5),'Color','k')
hold on
plot(strain_stats(:,1),strain_stats(:,3),'Color','k','LineStyle','--')
plot(strain_stats(:,1),strain_stats(:,7),'Color','k','LineStyle','--')
plot(strain_stats(:,1),strain_stats(:,6),'Color',[0.7 0.7 0.7],'LineStyle','-.')
plot(strain_stats(:,1),strain_stats(:,4),'Color',[0.7 0.7 0.7],'LineStyle','-.')
plot(strain_stats(:,1),strain_stats(:,8),'Color','k','LineStyle','-.')
plot(strain_stats(:,1),strain_stats(:,2),'Color','k','LineStyle','-.')
xlabel('Time [hours]');
ylabel('Strain fold change');


figure
plot(strainn_stats(:,1),strainn_stats(:,5),'Color','k')
hold on
plot(strainn_stats(:,1),strainn_stats(:,3),'Color','k','LineStyle','--')
plot(strainn_stats(:,1),strainn_stats(:,7),'Color','k','LineStyle','--')
plot(strainn_stats(:,1),strainn_stats(:,6),'Color',[0.7 0.7 0.7],'LineStyle','-.')
plot(strainn_stats(:,1),strainn_stats(:,4),'Color',[0.7 0.7 0.7],'LineStyle','-.')
plot(strainn_stats(:,1),strainn_stats(:,8),'Color','k','LineStyle','-.')
plot(strainn_stats(:,1),strainn_stats(:,2),'Color','k','LineStyle','-.')
xlabel('Time [hours]');
ylabel('Normalized Strain fold change');


NetStrain.MCMC_Strain=Netfit;

end