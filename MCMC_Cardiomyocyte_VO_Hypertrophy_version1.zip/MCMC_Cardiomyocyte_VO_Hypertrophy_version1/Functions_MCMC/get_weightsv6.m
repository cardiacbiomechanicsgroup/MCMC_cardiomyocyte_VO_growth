function xi=get_weightsv6(Netfit)
n=Netfit.Gibbs.N;
iGibb=Netfit.Gibbs.iGibb;
xi=-1*ones(1,4);
if Netfit.Gibbs.ON
    while(any(xi<0.005))
         if iGibb<n 
            xi(1)=random('Uniform',0.005,0.04);
            %xi(1)=random('Normal',0.0282,0.0032);
            xi(2)=Netfit.Iteration.weights(2);
            xi(3)=Netfit.Iteration.weights(3);
            xi(4)=Netfit.Iteration.weights(4);
            xi(5)=Netfit.Iteration.weights(5);          
         elseif iGibb>=n && iGibb<2*n
            xi(1)=Netfit.Iteration.weights(1);
            xi(2)=random('Uniform',0.005,0.14);
            %xi(2)=random('Normal',0.01134,0.0061);
            xi(3)=Netfit.Iteration.weights(3);
            xi(4)=Netfit.Iteration.weights(4);
            xi(5)=Netfit.Iteration.weights(5);     
         elseif iGibb>=2*n && iGibb<3*n
            xi(1)=Netfit.Iteration.weights(1);
            xi(2)=Netfit.Iteration.weights(2);
            xi(3)=random('Uniform',0.005,0.24);
            %xi(3)=random('Normal',0.0393,0.0131);
            xi(4)=Netfit.Iteration.weights(4);
            xi(5)=Netfit.Iteration.weights(5);               
         elseif iGibb>=3*n && iGibb<=4*n
            xi(1)=Netfit.Iteration.weights(1);
            xi(2)=Netfit.Iteration.weights(2);
            xi(3)=Netfit.Iteration.weights(3);
            xi(4)=random('Uniform',0.005,0.27);
            %xi(4)=random('Normal',0.0493,0.0239); 
            xi(5)=Netfit.Iteration.weights(5);
         elseif iGibb>=4*n && iGibb<=5*n
            xi(1)=Netfit.Iteration.weights(1);
            xi(2)=Netfit.Iteration.weights(2);
            xi(3)=Netfit.Iteration.weights(3);
            xi(4)=Netfit.Iteration.weights(4);
            xi(5)=random('Uniform',0,20);
            %xi(5)=random('Normal',6.4828,3.64);     
         end

    end
else
    while(any(xi<0.005))
        xi(1)=random('Uniform',0.005,0.05);
        xi(2)=random('Uniform',0.005,0.14);
        xi(3)=random('Uniform',0.005,0.24);
        xi(4)=random('Uniform',0.005,0.27); 
        xi(5)=random('Uniform',1,1000)*1e-2;        
        %xi(2)=random('Normal',0.012,0.02);
        %xi(3)=random('Normal',0.04,0.03);
        %xi(4)=random('Normal',0.06,0.04);
        %All=random('Uniform',0.01,0.04);
        %Ang2=random('Uniform',0.005,0.14);
        %NE=random('Uniform',0.005,0.24);
        %ET1=random('Uniform',0.005,0.27);
        %xi=[All Ang2 NE ET1];
    end
end
end