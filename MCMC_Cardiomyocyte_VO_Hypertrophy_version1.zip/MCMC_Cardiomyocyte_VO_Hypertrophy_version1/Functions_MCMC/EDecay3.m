function y=EDecay3(x,pars)
y=pars(1)*(exp(-x/pars(2)))+pars(3);
end