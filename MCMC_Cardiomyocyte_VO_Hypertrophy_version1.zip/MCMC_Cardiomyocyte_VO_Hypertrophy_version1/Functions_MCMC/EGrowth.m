function y=EGrowth4(x,pars)
y=pars(1).*(exp(pars(2).*x)-1);
end