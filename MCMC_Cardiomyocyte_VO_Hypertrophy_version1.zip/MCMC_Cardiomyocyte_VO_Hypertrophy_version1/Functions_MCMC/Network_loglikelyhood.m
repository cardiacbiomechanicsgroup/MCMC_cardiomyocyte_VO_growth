function likely=Network_loglikelyhood(Netfit)

Exp=Netfit.Exp;
tstep=Netfit.tsteps;
yG=Netfit.Iteration.yG;

middle=Netfit.Indexes.middle;
imiddle=Netfit.Indexes.imiddle;
iCellArea=Netfit.Indexes.iCellArea;
yll=yG(:,imiddle);


ts=Netfit.ts;
dCelldt=diff(yG(:,iCellArea))./diff(ts);

ll=0;


    for i=1:length(imiddle)
        if isfield(Exp,(char(middle(i))))
            Data=Exp.(char(middle(i)));
        end
        for j=1:length(Data(:,1))
            tj=round(Data(j,1)/tstep);
            yj=yll(tj,i)/yll(1,i);
            lli=(pdf('Normal',yj,Data(j,2),Data(j,3)));
            if lli<=0
                lli=1e-20;
            end
            ll=ll+log(lli);
            
        end
    end
    Data=Exp.Cell;
    for j=1:length(Data(:,1))
        tj=round(Data(j,1)/tstep);
        yj=yG(tj,iCellArea)/yG(1,iCellArea);
        lli=(pdf('Normal',yj,Data(j,2),Data(j,3)));
        if lli<=0
           lli=1e-20;
        end
        ll=ll+log(lli);
            
    end 
    %ll=ll+log(pdf('Normal',yG(1,iCellArea),0.5,0.1));
    %ll=ll+log(pdf('Normal',dCelldt(end),0,1e-5));
    % ll=ll+log(pdf('Normal',yG(1,iCellArea),0.5,0.1));
    % ll=ll+log(pdf('Normal',dCelldt(end),0,1e-5));
    lli=(pdf('Normal',yG(1,iCellArea),0.5,0.1));
    if lli<=0
       lli=1e-9;
    end
    ll=ll+log(lli);
    lli=(pdf('Normal',dCelldt(end),0,1e-4));
    if lli<=0
       lli=1e-9;
    end
    ll=ll+log(lli);

likely=ll;
if yG(1,iCellArea)>0.7 || yG(end,iCellArea)>0.925 || yG(end,iCellArea)/yG(1,iCellArea)>2.2 || yG(1,iCellArea)<0.2 || any(dCelldt<-1e-7) || dCelldt(end)>1e-3
    likely=-1e4+ll;
    %likely=1;
end
if ~isreal(ll) || isnan(ll)
    likely=-1e9+ll;
    %likely=1e-3;
end
end