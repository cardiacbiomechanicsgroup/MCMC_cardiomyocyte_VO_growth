function Netfit=filter_likelyhoods(Netfit, treshold)
%% Filter the MCMC analysis results for a given likelyhood treshold to rule out unphysiologycal or unlikely results
% Program developed by Johane Bracamonte, Ph.D.
% University of Alabama at Birmingham, USA.

%% Inputs
% Netfit: Data structure containing the results of the MCMC analysis of
%         molecular data.
%treshold: Cut value of the logarithm of the likelyhood to filter our
%          unlikely or unphysiologycal results
%% Output
% Netfit: data structure with filtered results and statistics.

%%
weight_header={'Background','Ang2','NE','ET1','Stretch Parameter'};

Netfit.Inputs.strains=readmatrix('Strain_samples_fromM-VData.txt','Delimiter',',');
Netfit.Inputs.strains0=Netfit.Inputs.strains(1,1);
Netfit.Inputs.strainw=0.06;


like_index=find((Netfit.Results.likelyhood>-treshold));
not_like_index=find((Netfit.Results.likelyhood<-treshold));
par_set=Netfit.Results.NetworkParameter(like_index,:);
like_stridx=Netfit.Results.Strain_index(like_index,:);
ll_set=Netfit.Results.likelyhood(like_index);

Netfit.Results.Filter.parameter_set=par_set;
Netfit.Results.Filter.effective=size(like_index,1)/size(Netfit.Results.likelyhood,1)*100
par_set_unique=unique(par_set,"rows");
Netfit.Results.Filter.par_unique=par_set_unique;
Netfit.Results.Filter.effective_unique=size(par_set_unique,1)/size(Netfit.Results.likelyhood,1)*100;

Strain_set=[];
for i=1:size(like_index,1)
    Strain_set=[Strain_set Netfit.Inputs.strains(:,like_stridx(i))];
end

Strain_min=Strain_set(end,:).';
Strain_max=Strain_set(6,:).';
CellArea_set=Netfit.Results.CellArea(:,like_index);
Cell_stats=[];
Celln=CellArea_set./CellArea_set(1,:);
Strn=Strain_set./Strain_set(1,:);
Netfit.Results.Filter.Correlation_matrix=corrcoef(par_set)

%% Get filtered network activation levels
Str_stats=[];

for i=1:Netfit.ntsteps
    SQ=quantile(Strn(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    CQ=quantile(Celln(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    Cell_stats=[Cell_stats; CQ];
    Str_stats=[Str_stats; SQ];
end

Netfit.Results.Filter.CellArea_set=CellArea_set;
Netfit.Results.Filter.CellArea_stats=Cell_stats;

FAKs=[];
STATs=[];
p38s=[];
JNKs=[];
ERK12s=[];

SERCs=[];
aMHCs=[];
bMHCs=[];
ANPs=[];
BNPs=[];

middle_set=Netfit.Results.middle_set;
output_set=Netfit.Results.output_set;

for i=1:length(like_index)
      lix=(like_index(i)-1)*Netfit.ntsteps+1;
      uix=like_index(i)*Netfit.ntsteps;
      middlei=middle_set(lix:uix,:);
      outi=output_set(lix:uix,:);
      FAKs=[FAKs middlei(:,1)/middlei(1,1)];
      STATs=[STATs middlei(:,2)/middlei(1,2)];
      p38s=[p38s middlei(:,3)/middlei(1,3)];
      JNKs=[JNKs middlei(:,5)/middlei(1,5)];
      ERK12s=[ERK12s middlei(:,7)/middlei(1,7)];
      %
      SERCs=[SERCs outi(:,1)/outi(1,1)];
      aMHCs=[aMHCs outi(:,2)/outi(1,2)];
      bMHCs=[bMHCs outi(:,3)/outi(1,3)];
      ANPs=[ANPs outi(:,4)/outi(1,4)];
      BNPs=[BNPs outi(:,5)/outi(1,5)];


end

FAK_stats=[];
STAT_stats=[];
p38_stats=[];
JNK_stats=[];
ERK_stats=[];
SERCA_stats=[];
aMHC_stats=[];
bMHC_stats=[];
ANP_stats=[];
BNP_stats=[];

for i=1:Netfit.ntsteps
    FAKQ=quantile(FAKs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    FAK_stats=[FAK_stats; FAKQ];
    STATQ=quantile(STATs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    STAT_stats=[STAT_stats; STATQ];
    p38Q=quantile(p38s(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    p38_stats=[p38_stats; p38Q];
    JNKQ=quantile(JNKs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    JNK_stats=[JNK_stats; JNKQ];
    ERKQ=quantile(ERK12s(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    ERK_stats=[ERK_stats; ERKQ];    SERCQ=quantile(SERCs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    SERCA_stats=[SERCA_stats; SERCQ];
    aMHCQ=quantile(aMHCs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    aMHC_stats=[aMHC_stats; aMHCQ];
    bMHCQ=quantile(bMHCs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    bMHC_stats=[bMHC_stats; bMHCQ];
    ANPQ=quantile(ANPs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    ANP_stats=[ANP_stats; ANPQ];
    BNPQ=quantile(BNPs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    BNP_stats=[BNP_stats; BNPQ];
end

Netfit.Results.Filter.FAK=FAKs;
Netfit.Results.Filter.FAK_stats=FAK_stats;

Netfit.Results.Filter.STAT=STATs;
Netfit.Results.Filter.STAT_stats=STAT_stats;

Netfit.Results.Filter.p38=p38s;
Netfit.Results.Filter.p38_stats=p38_stats;

Netfit.Results.Filter.JNK=JNKs;
Netfit.Results.Filter.JNK_stats=JNK_stats;

Netfit.Results.Filter.ERK=ERK12s;
Netfit.Results.Filter.ERK_stats=ERK_stats;

Netfit.Results.Filter.SERCA=SERCs;
Netfit.Results.Filter.SERCA_stats=SERCA_stats;

Netfit.Results.Filter.aMHC=aMHC_stats;
Netfit.Results.Filter.aMHC_stats=aMHC_stats;

Netfit.Results.Filter.bMHC=bMHCs;
Netfit.Results.Filter.bMHC_stats=bMHC_stats;

Netfit.Results.Filter.ANP=ANPs;
Netfit.Results.Filter.ANP_stats=ANP_stats;

Netfit.Results.Filter.BNP=BNPs;
Netfit.Results.Filter.BNP_stats=BNP_stats;
%% Plotting

%plot_NetworkMCMC(Netfit);
%plot_barNetworkMCMC(Netfit);

%Correlation matrix
xlabels={'Background','Ang2','NE','ET1','Stretch Parameter'};;
ylabels={'Background','Ang2','NE','ET1','Stretch Parameter'};;

figure
set(gca, 'Visible', 'on');
cmaprange = [0.5:0.005:1];
blank = [zeros(1,length(cmaprange) - 20), 0.01:0.05:1];
myrgbcmap = [blank',blank',cmaprange';1 1 1; flipud(cmaprange'),flipud(blank'),flipud(blank')];
colormap(myrgbcmap);
im=imagesc(Netfit.Results.Filter.Correlation_matrix,[-1,1]);

N=length(xlabels);
x = repmat(1:N,N,1); % generate x-coordinates
y = x'; % generate y-coordinates
lab=num2cell(Netfit.Results.Filter.Correlation_matrix);
lab=cellfun(@num2str,lab,'UniformOutput',false);
text(x(:),y(:),lab,'left');
title('Network Parameter Correlation Matrix')
set(gca,'Visible','on');
set(gca,'XAxisLocation','bottom');
set(gca,'XTick',1:length(xlabels));
set(gca,'XTickLabel',xlabels,'fontsize',10);
set(gca,'YTick',1:length(ylabels));
set(gca,'YTickLabel',ylabels,'fontsize',10);
colorbar

%%
    %Strain
str0=Netfit.Inputs.strains0;
a=par_set(:,end);
b=(1/str0).*log(Netfit.Inputs.strainw./a+1);

Stretch_min=a.*(exp(b.*Strain_min)-1);
Stretch_max=a.*(exp(b.*Strain_max)-1);


Netfit.Results.Filter.Correlation_matrix_stretch=corrcoef([par_set Stretch_min Stretch_max]);

xlabels={'Background','Ang2','NE','ET1','Stretch Parameter','Stretch min','Stretch max'};;
ylabels={'Background','Ang2','NE','ET1','Stretch Parameter','Stretch min','Stretch max'};;

figure
set(gca, 'Visible', 'on');
cmaprange = [0.5:0.005:1];
blank = [zeros(1,length(cmaprange) - 20), 0.01:0.05:1];
myrgbcmap = [blank',blank',cmaprange';1 1 1; flipud(cmaprange'),flipud(blank'),flipud(blank')];
colormap(myrgbcmap);
im=imagesc(Netfit.Results.Filter.Correlation_matrix_stretch,[-1,1]);
%im=heatmap(Netfit.Results.Filter.Correlation_matrix);
N=length(xlabels);
x = repmat(1:N,N,1); % generate x-coordinates
y = x'; % generate y-coordinates
lab=num2cell(Netfit.Results.Filter.Correlation_matrix_stretch);
lab=cellfun(@num2str,lab,'UniformOutput',false);
text(x(:),y(:),lab,'left');
title('Network Parameter Correlation Matrix')
set(gca,'Visible','on');
set(gca,'XAxisLocation','bottom');
set(gca,'XTick',1:length(xlabels));
set(gca,'XTickLabel',xlabels,'fontsize',10);
set(gca,'YTick',1:length(ylabels));
set(gca,'YTickLabel',ylabels,'fontsize',10);
colorbar




%Distribution of probability
variables=size(par_set,2);
par_set_ex=Netfit.Results.NetworkParameter(not_like_index,:);
ll_set_ex=Netfit.Results.likelyhood(not_like_index);
for i=1:(variables)
     figure
     scatter(par_set(:,4),par_set(:,i),[],ll_set,'filled')
     a=colorbar;
     colormap jet;
     a.Label.String='log(likelyhood)';
     hold on
     scatter(par_set_ex(:,4),par_set_ex(:,i),[],'b','filled','Marker','square','MarkerFaceAlpha',0.1,'MarkerEdgeAlpha',0.1)

 
     %scatter(1,1,100,'Marker','pentagram','MarkerEdgeColor','k','MarkerFaceColor','none');
     %xlim([0.5,1.5]);
     %ylim([0.5,1.5]);
     ylabel(strcat(char(weight_header(i)),'_{0}'))
     xlabel('ET1_{0}')
 end

for i=1:(variables)
     figure
     scatter(par_set(:,1),par_set(:,i),[],ll_set,'filled')
     a=colorbar;
     colormap jet;
     a.Label.String='log(likelyhood)';
     hold on
     scatter(par_set_ex(:,1),par_set_ex(:,i),[],'b','filled','Marker','square','MarkerFaceAlpha',0.1,'MarkerEdgeAlpha',0.1)

 
     %scatter(1,1,100,'Marker','pentagram','MarkerEdgeColor','k','MarkerFaceColor','none');
     %xlim([0.5,1.5]);
     %ylim([0.5,1.5]);
     ylabel(strcat(char(weight_header(i)),'_{0}'))
     xlabel('Background weights_{0}')
 end

for i=1:variables
    figure
    scatter(par_set(:,i),ll_set,[],ll_set,'filled')
    a=colorbar
    colormap jet;
    a.Label.String='log(likelyhood)';
    xlabel(strcat(char(weight_header(i)),'_{0}'))
    ylabel('Log(Likelyhood)')
end

%% Histograms
figure
histogram(par_set(:,1))
xlabel('Baseline Weight Background')
% 
figure
histogram(par_set(:,2))
xlabel('Angiotensin II Baseline Weight')
% 
figure
histogram(par_set(:,3))
xlabel('Norepirephrine Baseline Weight')
% 
figure
histogram(par_set(:,4))
xlabel('Endothelin 1 Baseline Weight')
% 
figure
histogram(par_set(:,5))
xlabel('Strain Mapping Parameter "a"')
% 
figure
histogram(log10(par_set(:,5)))
xlabel('log10(a)')
% 
figure
histogram(CellArea_set(1,:))
hold on 
histogram(CellArea_set(end,:))
legend({'Baseline','Chronic'})
xlabel('Cell Arra Activity')

figure
histogram(ll_set)
hold on 
histogram(ll_set_ex)
legend({'Likely sets','Excluded sets'})
xlabel('Likelyhood')
%% Parameter correlation

for i=1:variables
    for j=1:variables
        if (i~=j) && abs(Netfit.Results.Filter.Correlation_matrix(i,j))>0.3
            mu=[mean(par_set(:,i)) mean(par_set(:,j))];
            COVA=cov([par_set(:,i) par_set(:,j)]);
            Netfit.Results.Filter.COVA=COVA;
            figure
            hold on
            [X1,X2]=meshgrid(linspace(min(par_set(:,i)),max(par_set(:,i)),50),linspace(min(par_set(:,j)),max(par_set(:,j)),50));
            X=[X1(:) X2(:)];
            p=mvnpdf(X,mu,COVA);
            p=reshape(p,length(X1),length(X2));
            scatter(par_set(:,i), par_set(:,j), '.','k')
            xlabel(strcat(char(weight_header(i)),'_{0}'))
            ylabel(strcat(char(weight_header(j)),'_{0}'))
            contour(X1, X2,p)
        end
    end
end
% 

%% Statistics and Correlations 
% Noted correlations Background (1) and NE (3), NE (3) and ET1 (4) and ET1 (4) and Stretch base (5). 

Netfit.Results.Filter.Back=[mean(par_set(:,1)) std(par_set(:,1))];
Netfit.Results.Filter.ANG2=[mean(par_set(:,2)) std(par_set(:,2))];
Netfit.Results.Filter.NE=[mean(par_set(:,3)) std(par_set(:,3))];
Netfit.Results.Filter.ET1=[mean(par_set(:,4)) std(par_set(:,4))];
Netfit.Results.Filter.a=[mean(par_set(:,5)) std(par_set(:,5))];
Netfit.Results.Filter.Strain_stats=Str_stats;

Netfit.Results.Filter.like_index=like_index;

%% Write filtered files
writematrix(Netfit.Results.Filter.Correlation_matrix,'NetBStr07_all_correlation_matrix.txt','Delimiter',',');
writematrix(par_set,'NetBStr07_all_filtered_parameters','Delimiter',',');


%% Strain analysis and correlation


end