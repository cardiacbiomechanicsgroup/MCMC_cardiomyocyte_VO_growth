function M=BGrowth(x,pars)
M=pars(1)*(1-exp(-x/pars(2)))+1;
end