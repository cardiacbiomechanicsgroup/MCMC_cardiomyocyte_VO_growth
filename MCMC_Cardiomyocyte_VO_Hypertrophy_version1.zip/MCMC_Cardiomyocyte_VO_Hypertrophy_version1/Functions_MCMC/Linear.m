function y=linear(x,fpars)
y=fpars(1).*x+fpars(2);
end