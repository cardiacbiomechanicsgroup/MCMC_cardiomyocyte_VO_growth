function yG=Netrunv6(Iteration,Indexes)
% Sub routine to call Netflux for the iterative solution of the network
% model under the dynamics conditions randomly assigned in the main
% program.

It=Iteration;
Idx=Indexes;
weights= It.weights;
params=It.Netpars;

% Set input weights
for i=1:17
    params{1,1}(1,i)=weights(1);
end
%Main course alterations
params{1,1}(1,Idx.jANG2)=weights(2); %Input AngII
params{1,1}(1,Idx.jNE)=weights(3); %Input NE
params{1,1}(1,Idx.jET1)=weights(4); %Input ENT1
params{1,1}(1,Idx.jStr)=It.baseStretch; %Input Stretch

% External drugs
params{1,1}(1,10)=1e-3; %Input ISO
params{1,1}(1,14)=1e-3; %Input PE

options=[];
[t,y] = ode15s(@HypNetwork_v2_ODE,It.tspan0,It.y0(end,:),options,params);
yG=[]; 
yG=[yG; real(y(end,:))];
tspan=It.tspan;

 for i=2:It.ntsteps

    ANP=It.CANP(i);
    BNP=It.CBNP(i);
    Ang=It.CAng(i);
    NE=It.CNE(i);
    ET1=It.CET1(i);
    Str=It.CStr(i);

    params{1,1}(1,Idx.jANPi)=ANP; %Input ANP
    params{1,1}(1,Idx.jBNPi)=BNP; %Input BNP
    params{1,1}(1,Idx.jANG2)=Ang; %Input AngII
    params{1,1}(1,Idx.jET1)=ET1; %Input ENT1
    params{1,1}(1,Idx.jNE)=NE; %Input NE
    params{1,1}(1,Idx.jStr)=Str; %Input Stretch

    y0=yG(end,:);

    [t,y] = ode15s(@HypNetwork_v2_ODE,tspan,y0,options,params);

    yG=[yG; real(y(end,:))];

 end


end