function Netfit=NetHyperMCMCv8(Netfit,iterations)
%% This program fits baseline weights of cardiomyocyte hypertrophy Network inputs using the Markov Chain Monte Carlo (MCMC) method
% Program developed by Johane Bracamonte, Ph.D.
% University of Alabama at Birmingham, USA.

%% Inputs
% The program requires specifying:
% Netfit: Data structure containing the results of the organ-scale
%         analysis.
% iterations: Iterations for the MCMC analysis.

%% Output
% Data structure with MCMC output and statistics of network input
% parameters and predictions of network node activity.

%% Load Experimental data
addpath(genpath('Functions_MCMC'));
addpath(genpath('Functions_Pharma'));
addpath(genpath('Functions_Stretch'));
Netfit_Exp_6;

%% Strain mapping parameters
%Strain and mapping parameter
Netfit.filename='FStr060_2';
Netfit.Inputs.strains=readmatrix('Strain_samples_fromM-VData.txt','Delimiter',',');
Netfit.Inputs.strains0=0.5368;
Netfit.Inputs.strainw=0.060;
[dummy,Netfit.Inputs.strains_samplesize]=size(Netfit.Inputs.strains);
Netfit.Inputs.Nhold=20;
Netfit.Inputs.ihold=1;
Netfit.Inputs.input_parameters=[];
%% Gibb sampling parameters
Netfit.Gibbs.N=4;
Netfit.Gibbs.ON=true;
Netfit.Gibbs.iGibb=1; 

%% Network fixed parameters
Netfit.tG=5700;
Netfit.tsteps=12;
Netfit.ts=(0:Netfit.tsteps:(Netfit.tG-Netfit.tsteps)).';
Netfit.ntsteps=length(Netfit.ts);

%Read Network Parameters
[Netfit.params,y0] = HypNetwork_v2_loadParams();
Netfit.nspecies=length(y0);

%% Names and indexes of relevant nodes
input_parset_head={'ANG2_par1 ANG_par2 NE_par1 NE_par2 ET1_par1' 'Stretch_par1' 'ANP_par1' 'ANP_par2' 'BNP_par1' 'BNP_par2'};
inputs={'ANGII' 'ANPi' 'BNPi' 'ET1' 'NE' 'Stretch' 'AT1R' 'BAR' 'TNFa'};
outputs={'SERCA' 'aMHC' 'bMHC' 'ANP' 'BNP' 'sACT'};
middle={'FAK' 'STAT' 'Akt' 'p38' 'JNK' 'ERK5' 'ERK12' 'cGMP' 'ELK1' 'Ras' 'cAMP' 'Calcium' 'GSK3B' 'Integrins'};

iinput=[];
ioutput=[];
imiddle=[];


for i=1:length(inputs)
    idx=find(strcmp(Netfit.params{1,4},char(inputs(i))));
    iinput=[iinput idx];
end

for i=1:length(outputs)
    idx=find(strcmp(Netfit.params{1,4},char(outputs(i))));
    ioutput=[ioutput idx];
end

for i=1:length(middle)
    idx=find(strcmp(Netfit.params{1,4},char(middle(i))));
    imiddle=[imiddle idx];
end

Netfit.Indexes.inputs=inputs;
Netfit.Indexes.outputs=outputs;
Netfit.Indexes.middle=middle;
Netfit.Indexes.iCellArea=19;
Netfit.Indexes.iinput=iinput;
Netfit.Indexes.ioutput=ioutput;
Netfit.Indexes.imiddle=imiddle;
%% Reactions
% Mean and Variability of Input functions
Netfit.Inputs.Ang2=[4.46 0.98; 584 195; 2.7570 0.7930];
Netfit.Inputs.NE=[1.1077e-4 0.732e-4; 1.4610 0.211];
Netfit.Inputs.ANP=[5.1884e-4 2.6735e-4; 3.3163 0.4328];
Netfit.Inputs.BNP=[1.438e-1 2.29e-4; 1.05 0.05];
Netfit.Inputs.ET1=[3.0 1.0];
Netfit.Inputs.strainmap=[1e-2 5e-3];

% Network reactions
treact=17;
Netfit.Indexes.jANG2=1;
Netfit.Indexes.jANPi=2;
Netfit.Indexes.jBNPi=3;
Netfit.Indexes.jET1=6;
Netfit.Indexes.jNE=12;
Netfit.Indexes.jStr=15;
Netfit.Indexes.jReactions=[Netfit.Indexes.jANG2 Netfit.Indexes.jNE Netfit.Indexes.jET1 Netfit.Indexes.jStr Netfit.Indexes.jANPi Netfit.Indexes.jBNPi];

%% Array initialization
ll_set=[];
ll_all=[];

input_parset=[];

par_set=[];
par_all=[];

stridx_set=[];
stridx_all=[];

CellArea_set=[];
CellArea_all=[];

input_set=[];
output_set=[];
middle_set=[];

%% First iteration

%Function parameters
% Input parameters
istr=randi(Netfit.Inputs.strains_samplesize);
Netfit.Iteration.strainsampleidx=istr;
sample=Netfit.Inputs.strains(:,istr);
Netfit.Iteration.strainsample=sample;
Netfit.Iteration.strainpars=[2];
Netfit.Iteration.baseStretch=Netfit.Inputs.strainw;
Netfit.Iteration.ANGpars=[4.46 586 2.7570];
Netfit.Iteration.NEpars=[1.1077e-4 1.4610];
Netfit.Iteration.ET1pars=[3.0];
Netfit.Iteration.ANPpars=[5.1884e-4 3.3163];
Netfit.Iteration.BNPpars=[1.438e-1 1.05];

% Network parameter iteration
Netfit.Iteration.Netpars=Netfit.params;
Netfit.Iteration.Netpars{1,2}(Netfit.Indexes.iCellArea)=1000;
Netfit.Iteration.y0=y0;
Netfit.Iteration.tspan=[0 Netfit.tsteps];
Netfit.Iteration.tspan0=[0 8000];
Netfit.Iteration.ntsteps=Netfit.ntsteps;

% Get relevant input Weights
All=0.03;
Ang2=0.0104;
NE=0.0396;
ET1=0.0495297789232406;
Stra=Netfit.Iteration.strainpars;

Netfit.Iteration.weights=[All Ang2 NE ET1 Stra];
x=[Netfit.Iteration.ANGpars Netfit.Iteration.NEpars Netfit.Iteration.ET1pars Netfit.Iteration.ANPpars Netfit.Iteration.BNPpars Netfit.Iteration.Netpars{1,2}(Netfit.Indexes.iCellArea) istr Stra];
Netfit.Inputs.input_parameters=[Netfit.Inputs.input_parameters;x];
% Get time resolved input curves
Netfit=get_input_curvesv6(Netfit);

%Run network
options=[];
Netfit.Iteration.yG=Netrunv6(Netfit.Iteration, Netfit.Indexes);
Netfit.Iteration.y0=Netfit.Iteration.yG(1,:);

ll=Network_loglikelyhood(Netfit);

% Save first iteration
ll_set=[ll_set;ll];
ll_all=[ll_all;ll];
par_set=[par_set; Netfit.Iteration.weights];
par_all=[par_all; Netfit.Iteration.weights];
stridx_set=[stridx_set ; Netfit.Iteration.strainsampleidx Netfit.Iteration.strainpars];
stridx_all=[stridx_all; Netfit.Iteration.strainsampleidx Netfit.Iteration.strainpars];

CellArea_set=[CellArea_set Netfit.Iteration.yG(:,Netfit.Indexes.iCellArea)];
CellArea_all=[CellArea_set Netfit.Iteration.yG(:,Netfit.Indexes.iCellArea)];

input_parset=[input_parset; Netfit.Iteration.ANGpars Netfit.Iteration.NEpars Netfit.Iteration.ET1pars Netfit.Iteration.strainpars Netfit.Iteration.ANPpars Netfit.Iteration.BNPpars];
input_set=[input_set; Netfit.Iteration.yG(:,Netfit.Indexes.iinput)];
middle_set=[middle_set; Netfit.Iteration.yG(:,Netfit.Indexes.imiddle)];
output_set=[output_set; Netfit.Iteration.yG(:,Netfit.Indexes.ioutput)];

input0=Netfit.Iteration.yG(:,Netfit.Indexes.iinput);
middle0= Netfit.Iteration.yG(:,Netfit.Indexes.imiddle);
output0=Netfit.Iteration.yG(:,Netfit.Indexes.ioutput);

% Start iterations
ihold=1;
for i=1:iterations
    if rem(i,100)==0
        'Progress (%)...'
        i/iterations*100
    end
    % Get Network input parameters
    if ihold<Netfit.Inputs.Nhold
        ihold=ihold+1;
    else
        Netfit=get_Input_Netparametersv6(Netfit);
        ihold=1;
    end
    weights=get_weightsv6(Netfit);
    Netfit.Iteration.weights=weights;
    Netfit.Iteration.strainpars=weights(5);
    Netfit=get_input_curvesv6(Netfit);    

    %Run Network
    Netfit.Iteration.yG=Netrunv6(Netfit.Iteration, Netfit.Indexes);
    Netfit.Iteration.y0=Netfit.Iteration.yG(1,:);

    %Evaluate likelyhood
    ll=Network_loglikelyhood(Netfit);
    rand=random('Uniform',0,1);
    %test=exp(ll-ll_set(end));
    test=ll_set(end)/ll;
    %test=ll/ll_set(end);
    if test>rand
       ll_set=[ll_set;ll];
       par_set=[par_set; Netfit.Iteration.weights];
       stridx_set=[stridx_set; Netfit.Iteration.strainsampleidx Netfit.Iteration.strainpars];
       CellArea_set=[CellArea_set Netfit.Iteration.yG(:,Netfit.Indexes.iCellArea)];

       ll_all=[ll_all;ll];
       par_all=[par_all; Netfit.Iteration.weights];
       stridx_all=[stridx_all; Netfit.Iteration.strainsampleidx Netfit.Iteration.strainpars];
       CellArea_all=[CellArea_set Netfit.Iteration.yG(:,Netfit.Indexes.iCellArea)];

       input_parset=[input_parset; Netfit.Iteration.ANGpars Netfit.Iteration.NEpars Netfit.Iteration.ET1pars Netfit.Iteration.strainpars Netfit.Iteration.ANPpars Netfit.Iteration.BNPpars];
       input_set=[input_set; Netfit.Iteration.yG(:,Netfit.Indexes.iinput)];
       middle_set=[middle_set; Netfit.Iteration.yG(:,Netfit.Indexes.imiddle)];
       output_set=[output_set; Netfit.Iteration.yG(:,Netfit.Indexes.ioutput)];  
       input0=Netfit.Iteration.yG(:,Netfit.Indexes.iinput);
       middle0= Netfit.Iteration.yG(:,Netfit.Indexes.imiddle);
       output0=Netfit.Iteration.yG(:,Netfit.Indexes.ioutput);
    else
       ll_set=[ll_set;ll_set(end)];
       par_set=[par_set; par_set(end,:)];
       stridx_set=[stridx_set; stridx_set(end,:)];
       CellArea_set=[CellArea_set CellArea_set(:,end)];

       ll_all=[ll_all;ll];
       par_all=[par_all; Netfit.Iteration.weights];
       stridx_all=[stridx_all; Netfit.Iteration.strainsampleidx Netfit.Iteration.strainpars];
       CellArea_all=[CellArea_set Netfit.Iteration.yG(:,Netfit.Indexes.iCellArea)];

       input_parset=[input_parset; input_parset(end,:)];
       input_set=[input_set; input0];
       middle_set=[middle_set; middle0];
       output_set=[output_set; output0];    
    end
    if Netfit.Gibbs.ON
        if Netfit.Gibbs.iGibb>=Netfit.Gibbs.N*length(weights)
            Netfit.Gibbs.iGibb=1;
        else
            Netfit.Gibbs.iGibb=Netfit.Gibbs.iGibb+1;
        end
    end
end


% Write files
writematrix(CellArea_set,strcat(Netfit.filename,'Cell_Area_set.txt'),'Delimiter',',')
writematrix(par_set,strcat(Netfit.filename,'Network_weights.txt'),'Delimiter',',')
writematrix(Netfit.Inputs.strains(:,stridx_set(:,1)),strcat(Netfit.filename,'Strain_samples.txt'),'Delimiter',',')
writematrix(stridx_set(:,1),strcat(Netfit.filename,'Strain_indexes.txt'),'Delimiter',',')
writematrix(stridx_set(:,2),strcat(Netfit.filename,'Strain_parameter.txt'),'Delimiter',',')
writematrix(ll_set,strcat(Netfit.filename,'Likelyhood_set.txt'),'Delimiter',',')
writematrix(input_parset,strcat(Netfit.filename,'Input_parameterset.txt'),'Delimiter',',')
writematrix(input_set,strcat(Netfit.filename,'Input_nodes_set.txt'),'Delimiter',',')
writematrix(middle_set,strcat(Netfit.filename,'Middle_nodes_set.txt'),'Delimiter',',')
writematrix(output_set,strcat(Netfit.filename,'Output_nodes_set.txt'),'Delimiter',',')

%Write headerts

% Save sets into Structure
Netfit.Results.CellArea=CellArea_set;
Netfit.Results.CellArea_all=CellArea_all;
Netfit.Results.NetworkParameter=par_set;
Netfit.Results.NetworkParameter_all=par_all;
Netfit.Results.Strain_index=stridx_set;
Netfit.Results.Strain_index_all=stridx_all;
Netfit.Results.likelyhood=ll_set;
Netfit.Results.likelyhood_all=ll_all;
Netfit.Results.input_parameter_header=input_parset_head;
Netfit.Results.input_header=inputs;
Netfit.Results.middle_header=middle;
Netfit.Results.output_header=outputs
Netfit.Results.input_parameter=input_parset;
Netfit.Results.input=input_set;
Netfit.Results.middle=middle_set;
Netfit.Results.output=output_set;
Netfit.Results.wAll=[mean(par_set(:,1)) std(par_set(:,1))];
Netfit.Results.wAng2=[mean(par_set(:,2)) std(par_set(:,2))];
Netfit.Results.wNE=[mean(par_set(:,3)) std(par_set(:,3))];
Netfit.Results.wET1=[mean(par_set(:,4)) std(par_set(:,4))];

% Get stats
Cell_stats=[];
Celln=CellArea_set./CellArea_set(1,:);
for i=1:Netfit.ntsteps
    CQ=quantile(Celln(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    Cell_stats=[Cell_stats; CQ];
end

FAKs=[];%1
STATs=[];%2
Akts=[];%3
p38s=[];%4
JNKs=[];%5
ERK5s=[];%6
ERK12s=[];%7
cGMPs=[];%8
ELKs=[];%9
Rass=[];%10
cAMPs=[];%11
Calciums=[];%12
GSK3Bs=[];%13
Integrinss=[];%14

SERCs=[];
aMHCs=[];
bMHCs=[];
ANPs=[];
BNPs=[];
sACTs=[];
for i=1:iterations
      lix=(i-1)*Netfit.ntsteps+1;
      uix=i*Netfit.ntsteps;
      middlei=middle_set(lix:uix,:);
      outi=output_set(lix:uix,:);
      FAKs=[FAKs middlei(:,1)/middlei(1,1)];
      STATs=[STATs middlei(:,2)/middlei(1,2)];
      Akts=[Akts middlei(:,3)/middlei(1,3)];
      p38s=[p38s middlei(:,4)/middlei(1,4)];
      JNKs=[JNKs middlei(:,5)/middlei(1,5)];
      ERK5s=[ERK5s middlei(:,6)/middlei(1,6)];
      ERK12s=[ERK12s middlei(:,7)/middlei(1,7)];
      cGMPs=[cGMPs middlei(:,8)/middlei(1,8)];
      ELKs=[ELKs middlei(:,9)/middlei(1,9)];
      Rass=[Rass middlei(:,10)/middlei(1,10)];
      cAMPs=[cAMPs middlei(:,11)/middlei(1,11)];
      Calciums=[Calciums middlei(:,12)/middlei(1,12)];
      GSK3Bs=[GSK3Bs middlei(:,13)/middlei(1,13)];    
      Integrinss=[Integrinss middlei(:,14)/middlei(1,14)];        
      %
      SERCs=[SERCs outi(:,1)/outi(1,1)];
      aMHCs=[aMHCs outi(:,2)/outi(1,2)];
      bMHCs=[bMHCs outi(:,3)/outi(1,3)];
      ANPs=[ANPs outi(:,4)/outi(1,4)];
      BNPs=[BNPs outi(:,5)/outi(1,5)];
      sACTs=[sACTs outi(:,6)/outi(1,6)];
end
FAK_stats=[];
STAT_stats=[];
Akt_stats=[];
p38_stats=[];
JNK_stats=[];
ERK5_stats=[];
ERK_stats=[];
cGMP_stats=[];
ELK_stats=[];
Ras_stats=[];
cAMP_stats=[];
Calcium_stats=[];
GSK3B_stats=[];
Integrins_stats=[];

%
SERCA_stats=[];
aMHC_stats=[];
bMHC_stats=[];
ANP_stats=[];
BNP_stats=[];
sACT_stats=[];

for i=1:Netfit.ntsteps
    FAKQ=quantile(FAKs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    FAK_stats=[FAK_stats; FAKQ];
    %
    STATQ=quantile(STATs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    STAT_stats=[STAT_stats; STATQ];
    %
    AktQ=quantile(Akts(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    Akt_stats=[Akt_stats; AktQ];
    %
    p38Q=quantile(p38s(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    p38_stats=[p38_stats; p38Q];
    %
    JNKQ=quantile(JNKs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    JNK_stats=[JNK_stats; JNKQ];
    %
    ERK5Q=quantile(ERK5s(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    ERK5_stats=[ERK5_stats; ERK5Q];   
    %
    ERKQ=quantile(ERK12s(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    ERK_stats=[ERK_stats; ERKQ];    
    %
    cGMPQ=quantile(cGMPs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    cGMP_stats=[cGMP_stats; cGMPQ];  
    %
    ELKQ=quantile(ELKs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    ELK_stats=[ELK_stats; ELKQ];
    %
    RasQ=quantile(Rass(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    Ras_stats=[Ras_stats; RasQ];
    %
    cAMPQ=quantile(cAMPs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    cAMP_stats=[cAMP_stats; cAMPQ];
    %
    CalciumQ=quantile(Calciums(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    Calcium_stats=[Calcium_stats; CalciumQ];
    %
    GSK3BQ=quantile(GSK3Bs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    GSK3B_stats=[GSK3B_stats; GSK3BQ];
    %
    IntegrinsQ=quantile(Integrinss(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    Integrins_stats=[Integrins_stats; IntegrinsQ];
    %
    SERCQ=quantile(SERCs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    SERCA_stats=[SERCA_stats; SERCQ];
    %
    aMHCQ=quantile(aMHCs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    aMHC_stats=[aMHC_stats; aMHCQ];
    %
    bMHCQ=quantile(bMHCs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    bMHC_stats=[bMHC_stats; bMHCQ];
    %
    ANPQ=quantile(ANPs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    ANP_stats=[ANP_stats; ANPQ];
    %
    BNPQ=quantile(BNPs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    BNP_stats=[BNP_stats; BNPQ];
    %
    sACTQ=quantile(sACTs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    sACT_stats=[sACT_stats; sACTQ];
end

writematrix(FAK_stats,strcat(Netfit.filename,'FAK_stats.txt'),'Delimiter',',');
writematrix(STAT_stats,strcat(Netfit.filename,'STAT_stats.txt'),'Delimiter',',');
writematrix(Akt_stats,strcat(Netfit.filename,'Akt_stats.txt'),'Delimiter',',');
writematrix(p38_stats,strcat(Netfit.filename,'p38_stats.txt'),'Delimiter',',');
writematrix(JNK_stats,strcat(Netfit.filename,'JNK_stats.txt'),'Delimiter',',');
writematrix(ERK5_stats,strcat(Netfit.filename,'ERK5_stats.txt'),'Delimiter',',');
writematrix(ERK_stats,strcat(Netfit.filename,'ERK_stats.txt'),'Delimiter',',');
writematrix(cGMP_stats,strcat(Netfit.filename,'cGMP_stats.txt'),'Delimiter',',');
writematrix(ELK_stats,strcat(Netfit.filename,'ELK_stats.txt'),'Delimiter',',');
writematrix(Ras_stats,strcat(Netfit.filename,'Ras_stats.txt'),'Delimiter',',');
writematrix(cAMP_stats,strcat(Netfit.filename,'cAMP_stats.txt'),'Delimiter',',');
writematrix(Calcium_stats,strcat(Netfit.filename,'Calcium_stats.txt'),'Delimiter',',');
writematrix(GSK3B_stats,strcat(Netfit.filename,'GSK3B_stats.txt'),'Delimiter',',');
writematrix(Integrins_stats,strcat(Netfit.filename,'Integrins_stats.txt'),'Delimiter',',');
%
writematrix(SERCA_stats,strcat(Netfit.filename,'SERCA_stats.txt'),'Delimiter',',');
writematrix(aMHC_stats,strcat(Netfit.filename,'aMHC_stats.txt'),'Delimiter',',');
writematrix(bMHC_stats,strcat(Netfit.filename,'bMHC_stats.txt'),'Delimiter',',');
writematrix(ANP_stats,strcat(Netfit.filename,'ANP_stats.txt'),'Delimiter',',');
writematrix(BNP_stats,strcat(Netfit.filename,'BNP_stats.txt'),'Delimiter',',');
writematrix(sACT_stats,strcat(Netfit.filename,'sACT_stats.txt'),'Delimiter',',');

%Plot
t=Netfit.ts;
figure
stats=Cell_stats;
Data=Netfit.Exp.Cell;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('CellArea fold change')

figure
stats=FAK_stats;
Data=Netfit.Exp.FAK;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('FAK fold change')

figure
stats=STAT_stats;
Data=Netfit.Exp.STAT;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('STAT fold change')

figure
stats=p38_stats;
Data=Netfit.Exp.p38;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('p38 fold change')

figure
stats=JNK_stats;
Data=Netfit.Exp.JNK;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('JNK fold change')

figure
stats=ERK_stats;
Data=Netfit.Exp.ERK12;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('ERK fold change')

figure
stats=SERCA_stats;
Data=Netfit.Exp.SERCA;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('SERCA fold change')

figure
stats=aMHC_stats;
Data=Netfit.Exp.aMHC;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('aMHC fold change')

figure
stats=bMHC_stats;
Data=Netfit.Exp.bMHC;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('bMHC fold change')

figure
stats=ANP_stats;
Data=Netfit.Exp.ANP;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('ANP fold change')

figure
stats=BNP_stats;
Data=Netfit.Exp.BNP;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('BNP fold change')

figure
histogram(par_set(:,1))
xlabel('Baseline Weight Background')

figure
histogram(par_set(:,2))
xlabel('Angiotensin II Baseline Weight')

figure
histogram(par_set(:,3))
xlabel('Norepirephrine Baseline Weight')

figure
histogram(par_set(:,4))
xlabel('Endothelin 1 Baseline Weight')

figure
histogram(par_set(:,5))
xlabel('Strain Mapping Parameter "a"')

figure
histogram(log10(par_set(:,5)))
xlabel('log10(a)')

figure
histogram(ll_set)
xlabel('Likelyhood')

figure
scatter(par_set(:,1),par_set(:,2))
xlabel('Background Baseline Weight')
ylabel('Angiotensin Baseline Weight')

figure
scatter(par_set(:,1),par_set(:,3))
xlabel('Background Baseline Weight')
ylabel('Norepirephrine Baseline Weight')

figure
scatter(par_set(:,1),par_set(:,4))
xlabel('Background Baseline Weight')
ylabel('Endothelin 1 Baseline Weight')

figure
scatter(par_set(:,1),log(par_set(:,5)))
xlabel('Background Baseline Weight')
ylabel('log10(a)')

figure
scatter(par_set(:,2),par_set(:,3))
ylabel('Norepirephrine Baseline Weight')
xlabel('Angiotensin Baseline Weight')

figure
scatter(par_set(:,2),par_set(:,4))
ylabel('Endothelin 1 Baseline Weight')
xlabel('Angiotensin Baseline Weight')

figure
scatter(par_set(:,2),par_set(:,5))
ylabel('Endothelin 1 Baseline Weight')
xlabel('log10(a)')

figure
scatter(par_set(:,3),par_set(:,4))
ylabel('Endothelin 1 Baseline Weight')
xlabel('Norepirephrine Baseline Weight')

figure
scatter(par_set(:,3),par_set(:,5))
ylabel('log10(a)')
xlabel('Norepirephrine Baseline Weight')

figure
scatter(par_set(:,4),par_set(:,5))
ylabel('log10(a)')
xlabel('Endothelin 1 Baseline Weight')

figure
scatter(par_set(:,1),-ll_set)
xlabel('Background Baseline Weight')
ylabel('-log(Likelyhood)')

figure
scatter(par_set(:,2),-ll_set)
xlabel('Angiotensin Baseline Weight')
ylabel('-log(Likelyhood)')

figure
scatter(par_set(:,3),-ll_set)
xlabel('Norepirephrine Baseline Weight')
ylabel('-log(Likelyhood)')

figure
scatter(par_set(:,4),-ll_set)
xlabel('Endothelin 1 Baseline Weight')
ylabel('- Likelyhood')

figure
scatter(log10(par_set(:,5)),-ll_set)
xlabel('log10(a)')
ylabel('-log(Likelyhood)')
end