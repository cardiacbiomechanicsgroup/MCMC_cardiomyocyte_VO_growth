function Netfit=get_input_curvesv6(Netfit)
%Subroutine to estimate the dynamic changes of hormonal concentration as a
%fold change respect to baseline/control over time.

    It=Netfit.Iteration;
    weights= It.weights;
    % Angiotensin
    t=(0:Netfit.tsteps:Netfit.tG).';
    CAng=EDecay3(t,It.ANGpars);
    Netfit.Iteration.CAng=CAng*weights(2);
    
    %NE
    CNE=Linear(t,It.NEpars);
    Netfit.Iteration.CNE=CNE*weights(3);

    %ET1
    CET1=It.ET1pars*ones(Netfit.tG/Netfit.tsteps+1,1);
    Netfit.Iteration.CET1=CET1*weights(4);

    %ANP
    CANP=Linear(t,It.ANPpars);
    Netfit.Iteration.CANP=CANP*weights(1);

    %BNP
    CBNP=Linear(t,It.BNPpars);
    Netfit.Iteration.CBNP=CBNP*weights(1);

    %Strain
    str0=Netfit.Inputs.strains0;
    sample=It.strainsample;
    a=It.strainpars;
    b=(1/str0)*log(Netfit.Inputs.strainw/a+1);

    Strpars=[a b];
    CStr=EGrowth(sample,Strpars);

    Netfit.Iteration.Strainpars=Strpars;
    Netfit.Iteration.CStr=CStr;


end