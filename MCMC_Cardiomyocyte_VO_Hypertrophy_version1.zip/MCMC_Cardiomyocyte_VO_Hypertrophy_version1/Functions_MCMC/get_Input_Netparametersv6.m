function Netfit=get_Input_Netparametersv6(Netfit)
% Subroutine to randomly assign the parameter for the estimation of hormone
% concentration dynamics.

   Inputs=Netfit.Inputs;
   x=-1*ones(1,13);
    while (any(x<0))
        %Strain
        istr=randi([1,Inputs.strains_samplesize],1);
        Netfit.Iteration.strainsampleidx=istr;
        sample=Netfit.Inputs.strains(:,istr);
        Netfit.Iteration.strainsample=sample;
        Stra=random('Normal',Inputs.strainmap(1,1),Inputs.strainmap(1,2));
        Netfit.Iteration.strainpars=Stra;
        %Angiotensin
        Ang1=random('Normal',Inputs.Ang2(1,1),Inputs.Ang2(1,2));
        Ang2=random('Normal',Inputs.Ang2(2,1),Inputs.Ang2(2,2));
        Ang3=random('Normal',Inputs.Ang2(3,1),Inputs.Ang2(3,2));
        Netfit.Iteration.ANGpars=[Ang1 Ang2 Ang3];
        %NE
        NE1=random('Normal',Inputs.NE(1,1),Inputs.NE(1,2));
        NE2=random('Normal',Inputs.NE(2,1),Inputs.NE(2,2));
        Netfit.Iteration.NEpars=[NE1 NE2];
        % ET1
        ET1=random('Normal',Inputs.ET1(1),Inputs.ET1(2));
        Netfit.Iteration.ET1pars=ET1;
        %ANP
        ANP1=random('Normal',Inputs.ANP(1,1),Inputs.ANP(1,2));
        ANP2=random('Normal',Inputs.ANP(2,1),Inputs.ANP(2,2));
        Netfit.Iteration.ANPpars=[ANP1 ANP2];
        %BNP
        BNP1=random('Normal',Inputs.BNP(1,1),Inputs.BNP(1,2));
        BNP2=random('Normal',Inputs.BNP(2,1),Inputs.BNP(2,2));
        Netfit.Iteration.BNPpars=[BNP1 BNP2];
        %Growth time constant
        Tau=random('Uniform',600,1400);
        Netfit.Iteration.Netpars{1,2}(Netfit.Indexes.iCellArea)=Tau;
        x=[Ang1 Ang2 Ang3 NE1 NE2 ET1 ANP1 ANP2 BNP1 BNP2 Tau istr Stra];
    end
    Netfit.Inputs.input_parameters=[Netfit.Inputs.input_parameters;x];
end