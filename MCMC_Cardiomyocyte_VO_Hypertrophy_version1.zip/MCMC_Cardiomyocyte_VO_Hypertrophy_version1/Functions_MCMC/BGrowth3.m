function M=BGrowth3(x,pars)
M=pars(1)*(1-exp(-x/pars(2)))+pars(3);
end