function Netfit=NetInfusionMCv7(Load,KnockDownList,tG)
%% This program generates Monte Carlo simulation of infusion of knockdowns in VO. 
% Program developed by Johane Bracamonte, Ph.D.
% University of Alabama at Birmingham, USA.

%% Inputs
% The program requires specifying:
% Load: 
%   'VO' for volume overload 
%   'ANGII' for Angiotensin II infusion.
%   'ISO' for Isoproterenol Infusion.
%   'NEH' High dose infusion of Norepirephrine
%   'NEL' Low dose infusion of Norepirephrine.
% KnockDownList Cell array with name of the network nodes to knockdown/block.
% tG Total simulation time.

%% Iterations
inputs=Load;
iterations=1000;
%% Strain mapping parameters
%Strain and mapping parameter
KDL=KnockDownList; %List of species to Knock Down 
nKD=size(KDL,2);    %Number of species to Knock down
filename={''};
for i=1:nKD
    filename=strcat(filename,strcat('_',char(KDL(i))));
end
Netfit.tG=tG;
Netfit.filename=char(strcat(filename,'_test1000'));
Netfit.Inputs.strains0=0.5368;
Netfit.Inputs.strainw=0.060;
Netfit.Inputs.strains=readmatrix('Strain_samples_fromM-VData.txt','Delimiter',',');
[dummy,Netfit.Inputs.strains_samplesize]=size(Netfit.Inputs.strains);
%% Network fixed parameters

%Read Network Parameters
[Netfit.params,y0] = InfNetwork_v2_loadParams();
Netfit.nspecies=length(y0);

%% Infusion
inputs={Load};
Netfit.Indexes.Inputs=inputs;
iinputs=[];

for i=1:length(inputs)
    idx=find(strcmp(Netfit.params{1,4},char(inputs(i))));
    iinputs=[iinputs idx];
end

Netfit.Indexes.iinputs=iinputs;

%% Time step parameters
Netfit.tsteps=12;
Netfit.ts=(0:Netfit.tsteps:(Netfit.tG-Netfit.tsteps)).';
Netfit.ntsteps=length(Netfit.ts);

%% Names and indexes of relevant nodes
inputsnames={'AngII' 'ANPi' 'BNPi' 'ET1' 'NE' 'Stretch' 'AT1R' 'BAR' 'TNFa'};
outputs={'SERCA' 'aMHC' 'bMHC' 'ANP' 'BNP'};
middle={'FAK' 'STAT' 'Akt' 'p38' 'JNK' 'ERK5' 'ERK12' 'cGMP' 'ELK' 'Ras' 'cAMP' 'Calcium' 'GSK3B' 'Integrins'};

iinputsnames=[];
ioutput=[];
imiddle=[];
iKD=[]; %Knock Down Species List


for i=1:length(inputsnames)
    idx=find(strcmp(Netfit.params{1,4},char(inputsnames(i))));
    iinputsnames=[iinputsnames idx];
end

for i=1:length(outputs)
    idx=find(strcmp(Netfit.params{1,4},char(outputs(i))));
    ioutput=[ioutput idx];
end

for i=1:length(outputs)
    idx=find(strcmp(Netfit.params{1,4},char(outputs(i))));
    ioutput=[ioutput idx];
end

for i=1:length(middle)
    idx=find(strcmp(Netfit.params{1,4},char(middle(i))));
    imiddle=[imiddle idx];
end

for i=1:nKD
    idx=find(strcmp(Netfit.params{1,4},char(KDL(i))));
    iKD=[iKD idx];
end


Netfit.Indexes.inputs_names=inputsnames;
Netfit.Indexes.outputs=outputs;
Netfit.Indexes.middle=middle;
Netfit.Indexes.iCellArea=19;
Netfit.Indexes.iinputsnames=iinputsnames;
Netfit.Indexes.ioutput=ioutput;
Netfit.Indexes.imiddle=imiddle;
Netfit.Indexes.iknockdowns=iKD;
%% Reactions
% Mean and Variability of Input functions
Netfit.Inputs.Ang2=[4.46 0.98; 584 195; 2.7570 0.7930];
Netfit.Inputs.NE=[1.1077e-4 0.732e-4; 1.4610 0.211];
Netfit.Inputs.ANP=[5.1884e-4 2.6735e-4; 3.3163 0.4328];
Netfit.Inputs.BNP=[1.438e-3 2.29e-4; 1.05 0.05];
Netfit.Inputs.ET1=[3.0 1.0];
Netfit.Inputs.strainmap=[5.6628 1.38];

% Network reactions
treact=17;
Netfit.Indexes.jANG2=1;
Netfit.Indexes.jANPi=2;
Netfit.Indexes.jBNPi=3;
Netfit.Indexes.jET1=6;
Netfit.Indexes.jISO=10;
Netfit.Indexes.jNE=12;
Netfit.Indexes.jStr=15;
Netfit.Indexes.jStr=15;
Netfit.Indexes.jAT1R=37;
Netfit.Indexes.jBAR=45;
Netfit.Indexes.jET1R=82;
Netfit.Indexes.jReactions=[Netfit.Indexes.jANG2 Netfit.Indexes.jNE Netfit.Indexes.jET1 Netfit.Indexes.jStr Netfit.Indexes.jANPi Netfit.Indexes.jBNPi Netfit.Indexes.jAT1R Netfit.Indexes.jBAR];

if strcmp(char(inputs),'AngII')
   jInf=Netfit.Indexes.jANG2;
    Netfit_Exp_InfusionAng;
elseif strcmp(char(inputs),'NEH') || strcmp(char(inputs),'NEL')
   jInf=Netfit.Indexes.jNE;	
    Netfit_Exp_InfusionNE;
elseif strcmp(char(inputs),'ISO')
   jInf=Netfit.Indexes.jISO;
    Netfit_Exp_InfusionISO;
elseif strcmp(char(inputs),'ARB')
   jInf=Netfit.Indexes.jAT1R;
    Netfit_Exp_InfusionARB;
elseif strcmp(char(inputs),'bB')
   jInf=Netfit.Indexes.jBAR;
    Netfit_Exp_InfusionbB;
elseif strcmp(char(inputs),'ET1RB')
   jInf=Netfit.Indexes.jET1R;
    Netfit_Exp_6;
elseif strcmp(char(inputs),'VO')
   jInf=7;
   Netfit_Exp_6;
end

Netfit.Indexes.jInf=jInf;

%% First iteration
istr=randi(Netfit.Inputs.strains_samplesize);
Netfit.Iteration.strainsampleidx=istr;
sample=Netfit.Inputs.strains(:,istr);
Netfit.Iteration.strainsample=sample;
Netfit.Iteration.strainpars=[2];
Netfit.Iteration.baseStretch=Netfit.Inputs.strainw;
%
Netfit.Iteration.Netpars=Netfit.params;
Netfit.Iteration.Netpars{1,2}(Netfit.Indexes.iCellArea)=1200;
Netfit.Iteration.y0=y0;
Netfit.Iteration.tspan=[0 Netfit.tsteps];
Netfit.Iteration.tspan0=[0 8000];
Netfit.Iteration.ntsteps=Netfit.ntsteps;

%% Array initialization
y_set=[];
ll_set=[];
ll_all=[];

input_set=[];

par_set=[];
par_all=[];

stridx_set=[];
stridx_all=[];

CellArea_set=[];
CellArea_all=[];

inputs_set=[];
output_set=[];
middle_set=[];

Netfit.Iteration.baseStretch=Netfit.Inputs.strainw;
Netfit.Inputs.input_parameters=[];

%% Monte Carlo Simulation
for i=1:iterations
    if rem(i,100)==0
        'Progress (%)...'
        i/iterations*100
    end
    
    % Get Network input parameters
    Netfit.Iteration.Netpars{1,2}(Netfit.Indexes.iCellArea)=random('Uniform',600,1400);
    weights=get_weights_Infusion(Netfit);
    Netfit.Iteration.weights=weights;
    Netfit.Iteration.strainpars=weights(5);
    Netfit=get_Input_Netparametersv6(Netfit);
    Netfit=get_input_curvesv6(Netfit);
    Infusion=-1;
    while(Infusion<0)
        if strcmp(char(inputs),'AngII')
            Infusion=random('Normal',3.47,0.32);
            InfWeight=weights(2);
        elseif strcmp(char(inputs),'NEH')
           % Infusion=random('Normal',15.35294118,1.847509397);		
            Infusion=random('Normal',15.35294118,4.847509397);	            
            InfWeight=weights(3);
        elseif strcmp(char(inputs),'NEL')    
            Infusion=random('Normal',6.352941176,0.894796437);
            InfWeight=weights(3);
        elseif strcmp(char(inputs),'ISO')    
            %Infusion=random('Normal',132,5);
            Infusion=random('Normal',900,15);
            InfWeight=1e-3;
        elseif strcmp(char(inputs),'ARB')    
            %Infusion=random('Normal',132,5);
            Infusion=1e-3;
            InfWeight=1.0;
        elseif strcmp(char(inputs),'bB')    
            %Infusion=random('Normal',132,5);
            Infusion=1e-3;
            InfWeight=1.0;
        elseif strcmp(char(inputs),'ET1RB')    
            %Infusion=random('Normal',132,5);
            Infusion=1e-3;
            InfWeight=1.0; 
        elseif strcmp(char(inputs),'VO')    
            %Infusion=random('Normal',132,5);
            Infusion=weights(1);
            InfWeight=1.0;   
        end
    end
    Netfit.Iteration.Infusion=Infusion;
    Netfit.Iteration.InfWeight=InfWeight;
    %Run Network
    Netfit.Iteration.yG=NetInfusion_runv5(Netfit.Iteration, Netfit.Indexes);
    Netfit.Iteration.y0=Netfit.Iteration.yG(1,:);

    par_set=[par_set; Netfit.Iteration.weights];
    CellArea_set=[CellArea_set Netfit.Iteration.yG(:,Netfit.Indexes.iCellArea)];
    inputs_set=[inputs_set; Netfit.Iteration.yG(:,Netfit.Indexes.iinputsnames)];
    middle_set=[middle_set; Netfit.Iteration.yG(:,Netfit.Indexes.imiddle)];
    output_set=[output_set; Netfit.Iteration.yG(:,Netfit.Indexes.ioutput)];  
    y_set=[y_set; Netfit.Iteration.yG];
end


% Write files
writematrix(CellArea_set,strcat(Netfit.filename,'Cell_Area_set.txt'),'Delimiter',',')
writematrix(par_set,strcat(Netfit.filename,'Network_weights.txt'),'Delimiter',',')
writematrix(inputs_set,strcat(Netfit.filename,'Inputs_nodes_set.txt'),'Delimiter',',')
writematrix(middle_set,strcat(Netfit.filename,'Middle_nodes_set.txt'),'Delimiter',',')
writematrix(output_set,strcat(Netfit.filename,'Output_nodes_set.txt'),'Delimiter',',')

% Save sets into Structure
Netfit.Results.CellArea=CellArea_set;
Netfit.Results.CellArea_all=CellArea_all;
Netfit.Results.NetworkParameter=par_set;
Netfit.Results.inputs=inputs_set;
Netfit.Results.middle=middle_set;
Netfit.Results.output=output_set;
Netfit.Results.wAll=[mean(par_set(:,1)) std(par_set(:,1))];
Netfit.Results.wAng2=[mean(par_set(:,2)) std(par_set(:,2))];
Netfit.Results.wNE=[mean(par_set(:,3)) std(par_set(:,3))];
Netfit.Results.wET1=[mean(par_set(:,4)) std(par_set(:,4))];

% Get stats
Cell_stats=[];
Celln=CellArea_set./CellArea_set(1,:);
for i=1:Netfit.ntsteps
    CQ=quantile(Celln(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    Cell_stats=[Cell_stats; CQ];
end

Netfit.Results.CellArea_stats=Cell_stats;

ANG2s=[];
ANPis=[];
BNPis=[];
ET1s=[];
NEs=[];
Stretchs=[];
AT1Rs=[];
BARs=[];

FAKs=[];
STATs=[];
p38s=[];
JNKs=[];
ERK12s=[];
cGMPs=[];
ELKs=[];
Rass=[];

SERCs=[];
aMHCs=[];
bMHCs=[];
ANPs=[];
BNPs=[];

for i=1:iterations
      lix=(i-1)*Netfit.ntsteps+1;
      uix=i*Netfit.ntsteps;
      inputi=inputs_set(lix:uix,:);
      middlei=middle_set(lix:uix,:);
      outi=output_set(lix:uix,:);
      %
      ANG2s=[ANG2s inputi(:,1)/inputi(1,1)];
      ANPis=[ANPis inputi(:,2)/inputi(1,2)];
      BNPis=[BNPis inputi(:,3)/inputi(1,3)];
      ET1s=[ET1s inputi(:,4)/inputi(1,4)];      
      NEs=[NEs inputi(:,5)/inputi(1,5)];          
      Stretchs=[Stretchs inputi(:,6)/inputi(1,6)];      
      %
      FAKs=[FAKs middlei(:,1)/middlei(1,1)];
      STATs=[STATs middlei(:,2)/middlei(1,2)];
      p38s=[p38s middlei(:,3)/middlei(1,3)];
      JNKs=[JNKs middlei(:,5)/middlei(1,5)];
      ERK12s=[ERK12s middlei(:,7)/middlei(1,7)];
      cGMPs=[cGMPs middlei(:,8)/middlei(1,8)];
      ELKs=[ELKs middlei(:,9)/middlei(1,9)];
      Rass=[Rass middlei(:,10)/middlei(1,10)];
      %
      SERCs=[SERCs outi(:,1)/outi(1,1)];
      aMHCs=[aMHCs outi(:,2)/outi(1,2)];
      bMHCs=[bMHCs outi(:,3)/outi(1,3)];
      ANPs=[ANPs outi(:,4)/outi(1,4)];
      BNPs=[BNPs outi(:,5)/outi(1,5)];
end
ANG2_stats=[];
ANPi_stats=[];
BNPi_stats=[];
ET1_stats=[];
NE_stats=[];
Strch_stats=[];

FAK_stats=[];
STAT_stats=[];
p38_stats=[];
JNK_stats=[];
ERK_stats=[];
cGMP_stats=[];
ELK_stats=[];
Ras_stats=[];

SERCA_stats=[];
aMHC_stats=[];
bMHC_stats=[];
ANP_stats=[];
BNP_stats=[];

for i=1:Netfit.ntsteps
    ANGQ=quantile(ANG2s(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    ANG2_stats=[ANG2_stats; ANGQ];
    ANPiQ=quantile(ANPis(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    ANPi_stats=[ANPi_stats; ANPiQ];
    BNPiQ=quantile(BNPis(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    BNPi_stats=[BNPi_stats; BNPiQ];    
    ET1Q=quantile(ET1s(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    ET1_stats=[ET1_stats; ET1Q];    
    NEQ=quantile(NEs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    NE_stats=[NE_stats; NEQ];   
    StrchQ=quantile(Stretchs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    Strch_stats=[Strch_stats; StrchQ];     
    %
    FAKQ=quantile(FAKs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    FAK_stats=[FAK_stats; FAKQ];
    STATQ=quantile(STATs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    STAT_stats=[STAT_stats; STATQ];
    p38Q=quantile(p38s(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    p38_stats=[p38_stats; p38Q];
    JNKQ=quantile(JNKs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    JNK_stats=[JNK_stats; JNKQ];
    ERKQ=quantile(ERK12s(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    ERK_stats=[ERK_stats; ERKQ];    
    cGMPQ=quantile(cGMPs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    cGMP_stats=[cGMP_stats; cGMPQ];    
    ELKQ=quantile(ELKs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    ELK_stats=[ELK_stats; ELKQ]; 
    RasQ=quantile(Rass(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    Ras_stats=[Ras_stats; RasQ]; 
    %
    SERCQ=quantile(SERCs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    SERCA_stats=[SERCA_stats; SERCQ];
    aMHCQ=quantile(aMHCs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    aMHC_stats=[aMHC_stats; aMHCQ];
    bMHCQ=quantile(bMHCs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    bMHC_stats=[bMHC_stats; bMHCQ];
    ANPQ=quantile(ANPs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    ANP_stats=[ANP_stats; ANPQ];
    BNPQ=quantile(BNPs(i,:),[0.05 0.136 0.25 0.5 0.75 0.8640 0.95]);
    BNP_stats=[BNP_stats; BNPQ];
end
%
writematrix(ANG2_stats,strcat(Netfit.filename,'ANG2_stats.txt'),'Delimiter',',');
writematrix(ANPi_stats,strcat(Netfit.filename,'ANPi_stats.txt'),'Delimiter',',');
writematrix(BNPi_stats,strcat(Netfit.filename,'BNPi_stats.txt'),'Delimiter',',');
writematrix(ET1_stats,strcat(Netfit.filename,'ET1_stats.txt'),'Delimiter',',');
writematrix(NE_stats,strcat(Netfit.filename,'NE_stats.txt'),'Delimiter',',');
writematrix(Strch_stats,strcat(Netfit.filename,'Stretch_stats.txt'),'Delimiter',','); 
%
writematrix(FAK_stats,strcat(Netfit.filename,'FAK_stats.txt'),'Delimiter',',');
writematrix(STAT_stats,strcat(Netfit.filename,'STAT_stats.txt'),'Delimiter',',');
writematrix(p38_stats,strcat(Netfit.filename,'p38_stats.txt'),'Delimiter',',');
writematrix(JNK_stats,strcat(Netfit.filename,'JNK_stats.txt'),'Delimiter',',');
writematrix(ERK_stats,strcat(Netfit.filename,'ERK_stats.txt'),'Delimiter',',');
writematrix(cGMP_stats,strcat(Netfit.filename,'cGMP_stats.txt'),'Delimiter',',');
writematrix(ELK_stats,strcat(Netfit.filename,'ELK_stats.txt'),'Delimiter',',');
writematrix(Ras_stats,strcat(Netfit.filename,'Ras_stats.txt'),'Delimiter',',');
%
writematrix(SERCA_stats,strcat(Netfit.filename,'SERCA_stats.txt'),'Delimiter',',');
writematrix(aMHC_stats,strcat(Netfit.filename,'aMHC_stats.txt'),'Delimiter',',');
writematrix(bMHC_stats,strcat(Netfit.filename,'bMHC_stats.txt'),'Delimiter',',');
writematrix(ANP_stats,strcat(Netfit.filename,'ANP_stats.txt'),'Delimiter',',');
writematrix(BNP_stats,strcat(Netfit.filename,'BNP_stats.txt'),'Delimiter',',');
%
Netfit.Results.ANG2_stats=ANG2_stats;
Netfit.Results.ANPi_stats=ANPi_stats;
Netfit.Results.BNPi_stats=BNPi_stats;
Netfit.Results.ET1_stats=ET1_stats;
Netfit.Results.NE_stats=NE_stats;
Netfit.Results.Stretch_stats=Strch_stats;
%
Netfit.Results.FAK_stats=FAK_stats;
Netfit.Results.STAT_stats=STAT_stats;
Netfit.Results.p38_stats=p38_stats;
Netfit.Results.JNK_stats=JNK_stats;
Netfit.Results.ERK_stats=ERK_stats;
Netfit.Results.cGMP_stats=cGMP_stats;
Netfit.Results.ELK_stats=ELK_stats;
Netfit.Results.Ras_stats=Ras_stats;
%
Netfit.Results.SERCA_stats=SERCA_stats;
Netfit.Results.aMHC_stats=aMHC_stats;
Netfit.Results.bMHC_stats=bMHC_stats;
Netfit.Results.ANP_stats=ANP_stats;
Netfit.Results.BNP_stats=BNP_stats;

%Plot
t=Netfit.ts;
t2=[t; flip(t,1)];
figure
stats=Cell_stats;
Data=Netfit.Exp.Cell;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('CellArea fold change')

figure
histogram(CellArea_set(1,:))
hold on
histogram(CellArea_set(end,:))
legend({'Cell Area_{0}','Cell Area_{final}'})
xlabel('Cell Area Activity')
%%
%
figure
stats=ANG2_stats;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
ylabel('ANG2 fold change')

figure
stats=ANPi_stats;
Data=Netfit.Exp.Cell;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
ylabel('ANPi fold change')

figure
stats=BNPi_stats;
Data=Netfit.Exp.Cell;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
ylabel('BNPi fold change')

figure
stats=ET1_stats;
Data=Netfit.Exp.Cell;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
ylabel('ET1 fold change')

figure
stats=NE_stats;
Data=Netfit.Exp.Cell;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
ylabel('NE fold change')

figure
stats=Strch_stats;
Data=Netfit.Exp.Cell;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
ylabel('Stretch fold change')

%%
figure
stats=FAK_stats;
%Data=Netfit.Exp.FAK;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
%errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('FAK fold change')
%
figure
stats=STAT_stats;
%Data=Netfit.Exp.STAT;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
%errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('STAT fold change')

figure
stats=p38_stats;
%Data=Netfit.Exp.p38;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
%errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('p38 fold change')

figure
stats=JNK_stats;
%Data=Netfit.Exp.JNK;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
%errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('JNK fold change')

figure
stats=ERK_stats;
%Data=Netfit.Exp.ERK12;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
%errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('ERK fold change')

figure
stats=cGMP_stats;
%Data=Netfit.Exp.ERK12;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
%errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('cGMP fold change')

figure
stats=ELK_stats;
%Data=Netfit.Exp.ERK12;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
%errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('ELK fold change')

figure
stats=Ras_stats;
%Data=Netfit.Exp.ERK12;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
%errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('Ras fold change')

figure
stats=SERCA_stats;
%Data=Netfit.Exp.SERCA;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
%errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('SERCA fold change')

figure
stats=aMHC_stats;
%Data=Netfit.Exp.aMHC;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
%errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('aMHC fold change')

figure
stats=bMHC_stats;
%Data=Netfit.Exp.bMHC;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
%errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('bMHC fold change')

figure
stats=ANP_stats;
%Data=Netfit.Exp.ANP;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
%errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('ANP fold change')

figure
stats=BNP_stats;
%Data=Netfit.Exp.BNP;
plot(t,stats(:,1),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
hold on
plot(t,stats(:,7),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,4),'Color','k','LineStyle','-','LineWidth',2);
plot(t,stats(:,2),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,6),'Color','k','LineStyle','--','LineWidth',1);
plot(t,stats(:,5),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
plot(t,stats(:,3),'Color',[0.7 0.7 0.7],'LineStyle','-.','LineWidth',0.8);
%errorbar(Data(:,1),Data(:,2),Data(:,3),'LineStyle','none','Marker','o','Color','blue','MarkerFaceColor','#0000CC')
ylabel('BNP fold change')


end