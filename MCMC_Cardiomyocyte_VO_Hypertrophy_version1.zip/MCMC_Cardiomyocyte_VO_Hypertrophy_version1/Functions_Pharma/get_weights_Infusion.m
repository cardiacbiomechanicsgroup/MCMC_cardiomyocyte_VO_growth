function xi=get_weights_Infusion(Netfit)
% Subroutine to assign the input reaction weights depending on the weight
% for myoStrain input.

xi=-1*ones(1,4);

    while(any(xi<0.005))

        if Netfit.Inputs.strainw==0.02
            xi(1)=random('Normal',0.0319,0.002);
            xi(2)=random('Normal',0.0134,0.0048);
            xi(3)=random('Normal',0.0452,0.0030);
            xi(4)=random('Normal',0.0444,0.0175); 
            xi(5)=random('Normal',5.1254,2.09);  

        elseif Netfit.Inputs.strainw==0.050
            xi(1)=random('Normal',0.0309,0.0014);
            xi(2)=random('Normal',0.0129,0.002);
            xi(3)=random('Normal',0.0485,0.0156);
            xi(4)=random('Normal',0.0488,0.0094); 
            xi(5)=random('Normal',2.8906,1.0045);        

        elseif Netfit.Inputs.strainw==0.055;
            % ET1 - Background correlation neglected
            xi(1)=random('Normal',0.029656302, 0.002667339112);
            xi(2)=random('Normal',0.012958879, 0.004283683616);
            xi(3)=random('Normal',0.050713377, 0.0176249574355);
            xi(4)=random('Normal',0.044166689, 0.0146388575816); 
            xi(5)=random('Normal',3.4344477341, 1.14177928374318);    


        elseif Netfit.Inputs.strainw==0.060;
        % ET1 - Background correlation neglected
%         xi(1)=random('Normal',0.0311,0.0022);
%         xi(2)=random('Normal',0.01034,0.0020);
%         xi(3)=random('Normal',0.0333,0.01435);
%         xi(4)=random('Normal',0.05683,0.0254); 
%         xi(5)=random('Normal',5.6628,1.38);   

        %Strain base 0.06 % with Background and ET1 correlated
            xi(2)=random('Normal',0.01034,0.0020);
            xi(3)=random('Normal',0.0333,0.01435);
            xi(5)=random('Normal',5.6628,1.38);   
            x14=mvnrnd([0.0311 0.0563],[4.15317598575973e-06	-2.01625100815502e-05; -2.01625100815502e-05	0.000526861722050974]);
            xi(1)=x14(1);
            xi(4)=x14(2);

        elseif Netfit.Inputs.strainw==0.065;
        % ET1 - Background correlation neglected
            xi(1)=random('Normal',0.0283,0.0025);
            xi(2)=random('Normal',0.0122,0.0056);
            xi(3)=random('Normal',0.0402,0.0130);
            xi(4)=random('Normal',0.0490,0.0187); 
            xi(5)=random('Normal',6.5228,3.3099);  

        elseif Netfit.Inputs.strainw==0.070;
        % ET1 - Background correlation neglected
            xi(1)=random('Normal',0.0307,0.0012);
            xi(2)=random('Normal',0.0101,0.0017);
            xi(3)=random('Normal',0.0301,0.013);
            xi(4)=random('Normal',0.0570,0.0010); 
            xi(5)=random('Normal',5.92,0.80);  
        end

    end

end