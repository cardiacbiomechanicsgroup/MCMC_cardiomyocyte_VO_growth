%% Run Markov Chain Monte Carlo Analysis of Experimental data from animal models of VO
% Main program and subroutines by Johane Bracamonte, Ph.D.
% University of Alabama at Birmingham, USA. 

% This routine runs Markov Chain Monte Carlo (MCMC) analysis of experimental 
% data from animal models of VO. This routine completes the following analyzes:

% 1) MCMC of organ-scale data to generate the probability
% distribution of myocardial strain and write it in the file
% Strain_samples_fromM-VData.txt.

% 2) MCMC of molecular-scale data to calibrate the parameters of the
% Network model of cardiomyocyte hypertrophy.

% Details of the methods to be found in Bracamonte et al. (2024) PLOS Computational Biology.

% Adding library folders
addpath(genpath('Functions_MCMC'));
addpath(genpath('Functions_Pharma'));
addpath(genpath('Functions_Stretch'));

%1) Estimation of Strain variability
print('Running Organ-Scale data analysis...')
VO_MCMC=Strain_MCMC_variability;
% 2) Estimation of Network input parameters
print('Running Molecular-Scale data analysis...')
iterations=10000;
VO_MCMC=NetHyperMCMCv8(VO_MCMC,iterations);
% Filtering unlikely results
print('Filtering out unlikely results...')
VO_MCMC=filter_likelyhoods(VO_MCMC, 1200)