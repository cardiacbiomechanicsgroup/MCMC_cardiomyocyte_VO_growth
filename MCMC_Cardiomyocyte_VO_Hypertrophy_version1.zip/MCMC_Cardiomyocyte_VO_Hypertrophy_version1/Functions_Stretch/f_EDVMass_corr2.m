function Netfit=f_EDVMass_corr2(Netfit)

ssize=[6 6 11 17 6 10 10 10 9 6 5 5 5 7 7 8 5 7 5 6 17 5 5 5];
Mass=[1.373335034	0.067436591
1.422679691	0.055842429
1.256282473	0.038008822
1.180301084	0.029853128
1.299615596	0.0416694
1.144342895	0.114574402
1.287666208	0.129715839
1.276526473	0.059498952
1.326250763	0.049128551
1.648098548	0.124109113
0.965164735	0.054101935
1.014748476	0.053787494
1.048405495	0.06705592
1.18782742	0.118141444
1.218682913	0.046112366
1.202249685	0.069691119
1.256282473	0.038008822
1.183501044	0.047183753
1.189095639	0.056499454
1.276997722	0.044437995
1.194930273	0.036716906
1.219165047	0.071590358
1.291605928	0.076775873
1.390659756	0.094096112];

EDV=[1.62058432	0.098751599
1.868988207	0.107255854
1.814219274	0.117724295
1.427104432	0.114015896
2.10391707	0.218316886
1.458626302	0.154086585
1.76851888	0.195556271
1.811430882	0.091526605
1.462539195	0.046921456
2.256012397	0.102600485
1.169807987	0.0639617
1.331591619	0.067036218
1.501702462	0.121276083
1.46636908	0.282271884
1.791287056	0.08899545
1.799676735	0.106959402
1.881312843	0.130812782
1.363574784	0.062972814
1.333555652	0.045611224
1.507770721	0.045058817
1.648989772	0.070156712
1.203499866	0.138117372
1.685105677	0.359149308
2.404852526	0.478278391];



Data=[];
for i=1:length(ssize)
    for j=1:ssize(i)
        Dataj=[-1 -1];
        while(any(Dataj<0))
            EDVj=random('Normal',EDV(i,1),EDV(i,2));
            Masj=random('Normal',Mass(i,1),Mass(i,2));
            Dataj=[EDVj Masj];
        end
        Data=[Data; Dataj];
    end
end

mEDV=mean(Data(:,1))
mMas=mean(Data(:,2))
vEDV=var(Data(:,1))
vMas=var(Data(:,2))
corrcoef(Data)
COVA=cov(Data)
mu=[mEDV mMas];

%%
COVA(1,2)=0.037;
COVA(2,1)=0.037;
%%

Netfit.Exp.Cov.mu=mu;
Netfit.Exp.Cov.COVA=COVA;

figure
hold on
[X1,X2]=meshgrid(linspace(0.5,3.5,50),linspace(0.5,2.5,50));
%[X1,X2]=[linspace(0.5,3.5,50) linspace(0.5,2.5,50)];
X=[X1(:) X2(:)];
p=mvnpdf(X,mu,COVA);
p=reshape(p,length(X1),length(X2));
scatter(Data(:,1), Data(:,2), '.','b')
errorbar(EDV(:,1),Mass(:,1),Mass(:,2),Mass(:,2),EDV(:,2),EDV(:,2),'o','MarkerEdgeColor','k','MarkerFaceColor','k','Color','k')
xlabel('EDV fold change')
ylabel('LV Mass fold change')
contour(X1, X2,p)
legend({'Reported Experimental Data','Random Samples','Bivariate probability contour'})


figure
mdl=fitlm(Data(:,1), Data(:,2))
plot(mdl)
coefCI(mdl)
corrcoef(Data)



figure

contour(X1, X2,p)
hold on
xline(1.25,'-.','Slice 1');
xline(mEDV,'-','Slice 2');
xline(2,'--','Slice 3');
xlabel('EDV fold change')
ylabel('LV Mass fold change')

figure
[X1,X2]=meshgrid(repmat(1,1,50),linspace(0.5,2.5,50));
X=[X1(:) X2(:)];
p=mvnpdf(X,mu,COVA);
p=reshape(p,length(X1),length(X2));
plot(X2,p,'LineStyle','-.','Color','k')
hold on
[X1,X2]=meshgrid(repmat(mEDV,1,50),linspace(0.5,2.5,50));
X=[X1(:) X2(:)];
p=mvnpdf(X,mu,COVA);
p=reshape(p,length(X1),length(X2));
plot(X2,p,'k')
[X1,X2]=meshgrid(repmat(2,1,50),linspace(0.5,2.5,50));
X=[X1(:) X2(:)];
p=mvnpdf(X,mu,COVA);
p=reshape(p,length(X1),length(X2));
plot(X2,p,'LineStyle','--','Color','k')
ylabel('Probability Density Function')
xlabel('LV Mass fold change')
legend({'Slice 1','Slice 2','Slice 3'})

%randsample(x,1,true,a)
end

