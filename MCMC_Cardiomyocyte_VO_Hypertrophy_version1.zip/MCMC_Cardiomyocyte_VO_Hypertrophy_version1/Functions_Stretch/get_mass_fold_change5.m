function LVwallR=get_mass_fold_change5(x,Netfit)
Fg=BGrowth(x,Netfit.Fpars);
h0=Netfit.h0;
r0=Netfit.r0;

r0i=Netfit.r0*Fg;
LVwall0=Netfit.LVwall0;


LVwallR=(4*pi/3)*((r0i+h0).^3-r0i.^3)/LVwall0;
end