function Netfit=get_strain_curve6(Netfit)
V0=Netfit.V0;
r0=Netfit.r0;
EDV0=Netfit.EDV0;
EDr0=Netfit.EDr0;
strf0=Netfit.strf0;
lbf0=Netfit.lbf0;

A=Netfit.EDVA;
B=Netfit.EDVB;
C=Netfit.EDVC;
EDVpars=[A B C];

curve=[];

for i=0:Netfit.tsteps:Netfit.tG
    if i==0
       EDVi=EDV0;
    else
       EDVi=EDV0*BGrowth3(i,EDVpars);
    end
    EDri=(3*EDVi/(4*pi))^(1/3);
    if i<=3*Netfit.tsteps
        Fgi=1;
    else
        Fgi=BGrowth(i,Netfit.Fpars);
    end
    V0i=(4*pi/3)*(r0*Fgi)^3;
    lbdi=EDri/(r0*Fgi);
    stri=0.5*(lbdi^2-1);
    LVwallR=get_mass_fold_change5(i,Netfit);
    curve=[curve; i stri stri/strf0 lbdi lbdi/lbf0 Fgi EDVi V0i LVwallR];
end
Netfit.curve=curve;
Netfit.mvrat_now=[Netfit.LVwall0/Netfit.EDV0 LVwallR*Netfit.LVwall0/EDVi LVwallR/(EDVi/EDV0)];
end