function likelyhood=F_likelyhood5(Data, Netfit)

ldata=length(Data.t);
Fpars=Netfit.Fpars;
% Get long late EDV growth
EDVA=Netfit.EDVA;
EDVB=Netfit.EDVB;
EDVC=Netfit.EDVC;
EDVpars=[EDVA EDVB EDVC];
x=[0.5*EDVB EDVB 2*EDVB 3*EDVB 4*EDVB 5*EDVB Netfit.tG 0.5*EDVB EDVB 2*EDVB 3*EDVB 4*EDVB 5*EDVB Netfit.tG];
EDVs=BGrowth3(x,EDVpars);



%% From Covariance bivariate distribution
ll=0;
mu=Netfit.Exp.Cov.mu;
COVA=Netfit.Exp.Cov.COVA;
m=get_mass_fold_change5(x,Netfit);  

for i=1:length(x)
    if m(i)>3.0
        top=m(i);
    else
        top=3.0;
    end
    [X1,X2]=meshgrid(repmat(EDVs(i),1,100),linspace(0.5,ceil(top),100));
    X=[X1(:) X2(:)];
    p=mvnpdf(X,mu,COVA);   
    p=reshape(p,length(X1),length(X2));
    pMass=p(:,1)./sum(p(:,1));
    lli=interp1(X2(:,1), pMass, m(i));
    ll=ll+log(lli);
end



%%
if isreal(ll)
    likelyhood=ll;
else
    likelyhood=-1e9;
end
end
