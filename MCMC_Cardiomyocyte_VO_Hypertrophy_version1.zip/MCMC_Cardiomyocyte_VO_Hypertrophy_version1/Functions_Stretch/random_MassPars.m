function pars=random_MassPars(pars0,Netfit)
n=Netfit.Gibbs.N;
iGibb=Netfit.Gibbs.iGibbs;
xi=[-1 -1];
if iGibb<0
    while(any(xi<0));
        %xi(1)=random('Uniform', 0.2,2.0);
         xi(2)=random('Uniform', 100, 1400);
         xi(1)=random('Normal', 0.2508,0.0810);
         %xi(2)=random('Normal', 1140, 300);
    end
else
    while(any(xi<0))
        if iGibb<n 
        %xi(1)=random('Uniform', 0.2,2.0);
            xi(1)=random('Normal', 0.2608,0.0910);
            xi(2)=pars0(2);
        else
            %xi(2)=random('Normal', 1140,300);
            xi(2)=random('Uniform', 100, 1400);
            xi(1)=pars0(1);         
        end
    end
end
pars=xi;
end
