%% Experimental data for Validation of Bayesian Calibration
% Bracamonte et al. 2025 PLOS Computational Biology
% Effect of drugs to protect against hypertrophy induced by volume overload 
% as defined in equation 7 of the main manuscript.

% Array contains mean drug effect and standard deviation.
%% Beta blockers in early VO

% Sabri et al. 10.1161/CIRCRESAHA.107.163642
% Trapanesse et al. 10.1007/s00395-014-0456-3
Exp.VObB.Early.Dog=[0	0.0481040538832228
0	0.0430116263352131
0.0260617760000000	0.205494859977506];

% Seqqat 10.1016/j.yjmcc.2012.05.004
% Kobayashi 10.1292/jvms.70.1231
Exp.VObB.Earl.Rat=[0.0600000000000001	0.0640312423743285
0.000278502000000014	0.205034531995233
-0.119545930000000	0.174796034464714];

%% Beta blockers in early VO

% Pat et al. 2008 10.1152/ajpheart.00746.2008
Exp.VObB.Chronic.Dog=[0.154250746000000	0.0539654330057162];
%Kobayashi et al. 10.1292/jvms.70.1231 
Exp.VObB.Chronic.Rat=[0.296398377000000	0.165700478942467];

%% Angiotensin Receptor Blockers in Chronic VO

%Perry et al.
Exp.VOARB.Dog=[-0.0606074560000001	0.101816166438647];

% Zhang et al. https://doi.org/10.1177/1074248409356430
% Ishiye 10.1248/BPB.18.700
% Ruzicka 10.1161/01.CIR.87.3.921
 
Exp.VOARB.Rat=[-0.11	0.111198021565134
               -0.29	0.110639052779749
               -0.24	0.110390216957845
               -0.18	0.0799312204335703];

%% Endothelin Receptor Antagonist in Chronic VO
% Murray et al. 2008 10.1152/ajpheart.00622.2007
% Murray et al. 2009 10.1152/ajpheart.00968.2008
% Francis et al. 10.1097/01.fjc.0000166214.42791.f2
% Lee et al.  10.4070/kcj.2005.35.9.665

Exp.VOERA.Rat=[-0.42	0.0583095189484530
               -0.39	0.0699714227381436
               -0.03	0.0141421356237310
               -0.06	0.0141421356237310];