%% Experimental data for Validation of Bayesian Calibration
% Bracamonte et al. 2025 PLOS Computational Biology
% Effect of drugs to protect against hypertrophy induced by infusion of agonists 
% as defined in equation 7 of the main manuscript.

% Array contains mean drug effect and standard deviation.

%% Beta blockers on top of ISO infusion
%Sources
% Hanada	https://doi.org/10.1016/j.ejphar.2008.04.055
% Hanada	https://doi.org/10.1016/j.ejphar.2008.04.055
% Bolyut	https://doi.org/10.1152/ajpheart.1995.269.2.H638
% Bolyut	https://doi.org/10.1152/ajpheart.1995.269.2.H638
% Bolyut	https://doi.org/10.1152/ajpheart.1995.269.2.H638
% Bolyut	https://doi.org/10.1152/ajpheart.1995.269.2.H638
% Grim	https://doi.org/10.1016/S1054-8807(99)00021-6
% Kitagawa	https://doi.org/10.1152/ajpheart.00073.2004 

Exp.ISObB=[-0.348126636	0.021121249
-0.209951037	0.020817601
-0.276978417	0.048134472
-0.399280576	0.057126409
-0.261818182	0.064125605
-0.261818182	0.06439738
-0.32	0.038691084
-0.107007866	0.113042729];

%% Angiotensin Receptor Blocker on top of ISO infusion

%Sources
% Leenen* ISO+ARB	https://doi.org/10.1152/ajpheart.2001.281.6.H2410
% Golomb	https://doi.org/10.1152/ajpheart.1994.267.4.H1496
% Golomb	https://doi.org/10.1152/ajpheart.1994.267.4.H1496
% Golomb	https://doi.org/10.1152/ajpheart.1994.267.4.H1496
% Miyoshi	
% Bhoomika	https://doi.org/10.1080/AC.67.2.2154211
% Grim	https://doi.org/10.1016/S1054-8807(99)00021-6

Exp.ISOARB=[-0.016487815	0.05949489
-0.126394052	0.032906402
-0.081784387	0.0630215
-0.108108108	0.045459044
-0.050746269	0.148055233
-0.547945205	0.188614722
-0.22	0.053034187];

%% Endothelin Receptor Antagonist on top of Angiotensin II Infusion
%Sources
% Herizi 	https://doi.org/10.1161/01.HYP.31.1.10
% Ficai	https://doi.org/10.1046/j.1440-1681.2001.03568.x
% Park	https://doi.org/10.1016/S0895-7061(01)02291-9

Exp.ANGERA=[-0.135135135	0.027679118
-0.107744108	0.060860026
-0.021538462	0.134041984];

%% Endothelin Receptor Antagonist on top of Norepirephrine
%Sources
%Kaddoura NE+ET1	https://doi.org/10.1161/01.CIR.93.11.2068

Exp.NEERA=[-0.238197425	0.056724943];