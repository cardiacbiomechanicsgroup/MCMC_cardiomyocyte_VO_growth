%% Experimental data for Validation of Bayesian Calibration
% Bracamonte et al. 2025 PLOS Computational Biology
% Effect of infusion of agonists as defined in equation 6 of the main
% manuscript
% Array contains time[hours] mean fold change standard deviation

%% Isoproterenol Infusion in Rats

%LV mass fold change
% Sources       Doi                                                     Dose
% Leenen	    https://doi.org/10.1152/ajpheart.2001.281.6.H2410	    40 mg/kg/day
% Ennis	        https://doi.org/10.1161/01.HYP.0000071180.12012.6E 	    5mg/kg/day
% Murad	        https://doi.org/10.1046/j.1440-1681.2000.03254.x 	    0.8 mg/kg/day
% Nagano	    https://doi.org/10.1161/01.HYP.19.6.708	                4.2 mg/kg/day
% Brand	        https://doi.org/10.1006/jmcc.1993.1145	                5 mg/kg/day
% Al-rasheed	https://doi.org/10.2147/DDDT.S86431 	                5 mg/kg/day
% Chowdhury	    https://doi.org/10.1186/1479-5876-11-130    	        5 mg/kg/day
% Takeshita	    https://doi.org/10.2170/physiolsci.RP004508	            1.2 mg/kg/day
% Boluyt	    https://doi.org/10.1152/ajpheart.1995.269.2.H638	    2.4 mg/kg/day
% Golomb	    https://doi.org/10.1152/ajpheart.1994.267.4.H1496	    5 mg/kg/day
% Golomb	    https://doi.org/10.1152/ajpheart.1994.267.4.H1496	    10 mg/kg/day
% Golomb	    https://doi.org/10.1152/ajpheart.1994.267.4.H1496	    20 mg/kg/day
% Miyoshi	    	                                                    2.4 mg/kg/day
% Hanada	    https://doi.org/10.1016/j.ejphar.2008.04.055	        8mg/kg/day
% Grim	        https://doi.org/10.1016/S1054-8807(99)00021-6	        10 mg/kg/day


Exp.ISO.LVM=[168	1.224814184	0.056646839
         720	1.362139918	0.074704963
         192	1.352941176	0.037111634
         168	1.160550459	0.046452749
         168	1.201780415	0.203361411
         168	1.567567568	0.10050665
         336	1.558139535	0.118239724
         168	1.273195876	0.097544349
         192	1.323636364	0.069654455
         192	1.130111524	0.027345187
         192	1.271375465	0.031205866
         192	1.304832714	0.078667398
         168	1.334328358	0.15848849
         672	1.404030906	0.141407021
         336	1.52	0.045486262];

% SERCA Kitagawa	https://doi.org/10.1152/ajpheart.00073.2004 
%       Boluyt	    https://doi.org/10.1152/ajpheart.1995.269.2.H638
Exp.ISO.SERCA=[72 0.68	0.140001651
           72 0.48	0.200000576
           72 0.85	0.060006021];

% ANP Chowdhury	https://doi.org/10.1186/1479-5876-11-130 
Exp.ISO.ANP=[336 7.210526316 3.894284816];

% aMHC Boluyt	https://doi.org/10.1152/ajpheart.1995.269.2.H638
Exp.ISO.aMHC=[72 0.717	0.028053123];

%bMHC Takeshita	https://doi.org/10.2170/physiolsci.RP004508
%     Boluyt	https://doi.org/10.1152/ajpheart.1995.269.2.H638
Exp.ISO.bMHC=[72 4.610294118	1.473180566
          72 1.95	0.420004527];

%% Angiotensin II Infusion in Rats

% LV mass fold change
%Source     DOI                                                 Dose
%Griffin	https://doi.org/10.1161/01.HYP.17.5.626	            200 ng/kg/min
% Dostal	https://doi.org/10.1093/ajh/5.5.276	                100 ng/kg/min
% Dostal	https://doi.org/10.1093/ajh/5.5.276	                100 ng/kg/min
% Dilley	https://doi.org/10.1016/S0008-6363(98)00004-2	    200 ng/kg/min
% Dilley	https://doi.org/10.1016/S0008-6363(98)00004-2	    200 ng/kg/min
% Baltatu	https://doi.org/10.1161/01.HYP.35.1.409	            100 ng/kg/min
% Kim	    https://doi.org/10.1161/01.HYP.25.6.1252	        200 ng/kg/min
% Kim	    https://doi.org/10.1161/01.HYP.25.6.1252	        200 ng/kg/min
% Kim	    https://doi.org/10.1161/01.HYP.25.6.1252	        200 ng/kg/min
% Rong	    https://journals.lww.com/jhypertension/fulltext/2004/04000/NAD_P_H_oxidase_activation_by_angiotensin_II_is.23.aspx	200 ng/kg/min
% Mishra	https://doi.org/10.1093/biolre/ioy179	            120 ng/kg/min
% Grobe	    https://doi.org/10.1152/ajpheart.00937.2006	        100 ng/kg/min
% Goldspink	https://doi.org/10.1023/A:1012789819926 	        200 ng/kg/min
% Cassis	https://doi.org/10.1152/ajpendo.1998.274.5.E867	    175 ng/kg/min
% Cassis	https://doi.org/10.1152/ajpendo.1998.274.5.E867	    200 ng/kg/min
% Bruno	    10.1097/HJH.0b013e328121aae7	                    100 ng/kg/min
% Bruno	    10.1097/HJH.0b013e328121aae7	                    200 ng/kg/min
% Bruno	    10.1097/HJH.0b013e328121aae7	                    200 ng/kg/min
% Bruno	    10.1097/HJH.0b013e328121aae7	                    200 ng/kg/min
% Bruno	    10.1097/HJH.0b013e328121aae7	                    200 ng/kg/min
% Herizi    https://doi.org/10.1161/01.HYP.31.1.10	            200 ng/kg/min

Exp.ANG.LVM=[240	1.115241636	0.022364813
             168	1.234513274	0.039007432
             336	1.204347826	0.470294549
             336	1.121212121	0.042562039
             336	1.231441048	0.062814006
             168	1.106280193	0.040145716
             24	    1.009328358	0.034346526
             72	    1.115107914	0.034529648
             168	1.17611336	0.025249421
             168	1.195555556	0.043059345
             672	1.347826087	0.197832387
             672	1.106	0.302347583
             168	1.24535316	0.084075138
             336	1.178571429	0.01834652
             168	1.176470588	0.09847248
             168	0.934010152	0.047022005
             336	1.065989848	0.040738487
             168	1.119791667	0.042742724
             336	1.086294416	0.041082548
             672	1.243093923	0.041040885
             240	1.152027027	0.029441263];

%ANP Baltatu	https://doi.org/10.1161/01.HYP.35.1.409
%    Kim	https://doi.org/10.1161/01.HYP.25.6.1252
Exp.ANG.ANP=[168    2.385090218	0.668597038
             168    5.3	1.515836733];

%aMHC Kim	https://doi.org/10.1161/01.HYP.25.6.1252
Exp.ANG.aMHC=[168 1.04	0.176015385];

%bMH Kim	https://doi.org/10.1161/01.HYP.25.6.1252
%    Goldspink	https://doi.org/10.1023/A:1012789819926 
Exp.ANG.bMHC=[168 1.9	0.483255626
              168 5.454545455	0.753834992];

%SERCA Cassis	https://doi.org/10.1152/ajpendo.1998.274.5.E867
Exp.ANG.SERCA=[336 0.777606178	0.059150147];

%% Norepirephrine Infusion in Dogs

%LV mass fold change
%Source     DOI
% Laks	    https://doi.org/10.1378/chest.64.1.75
% King	    https://doi.org/10.1161/01.HYP.9.6.582
% Stewart	https://doi.org/10.1152/ajpheart.1992.262.2.H331
% Raum	    https://doi.org/10.1161/01.CIR.68.3.693

Exp.NE.LVM=[4300	1.136824324	0.050061151
            672	1.202985075	0.048282517
            672	1.612587413	0.195959143
            2184	1.061068702	0.090384777];

